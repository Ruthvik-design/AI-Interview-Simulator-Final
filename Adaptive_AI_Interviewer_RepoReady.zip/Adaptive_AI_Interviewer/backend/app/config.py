
import os
from dotenv import load_dotenv

load_dotenv()


class Config:

    SQLALCHEMY_DATABASE_URI = os.getenv(
        'DATABASE_URI',
        'sqlite:///interview_simulator.db'
    )

    SQLALCHEMY_TRACK_MODIFICATIONS = False

    OLLAMA_BASE_URL = os.getenv(
        'OLLAMA_BASE_URL',
        'http://127.0.0.1:11434'
    )

    OLLAMA_MODEL = os.getenv(
        'OLLAMA_MODEL',
        'llama3.2:3b'
    )

    JWT_SECRET_KEY = os.getenv(
        'JWT_SECRET_KEY',
        'default-jwt-secret-key-12345'
    )
