
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), default="user")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class InterviewSession(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(
        db.Integer,
        db.ForeignKey("user.id"),
        nullable=True
    )

    user_name = db.Column(
        db.String(100),
        default="Candidate User"
    )

    role = db.Column(db.String(100), nullable=False)
    experience = db.Column(db.String(50), nullable=False)
    interview_type = db.Column(db.String(50), nullable=False)

    time_limit_minutes = db.Column(db.Integer, default=10)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    overall_score = db.Column(db.Float, default=0.0)
    scores_json = db.Column(db.Text, nullable=True)
    feedback_summary = db.Column(db.Text, nullable=True)
    improvements_json = db.Column(db.Text, nullable=True)


class ChatHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    session_id = db.Column(
        db.Integer,
        db.ForeignKey("interview_session.id"),
        nullable=False
    )

    sender = db.Column(db.String(20), nullable=False)
    message = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)


class AgentFeedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    session_id = db.Column(
        db.Integer,
        db.ForeignKey("interview_session.id"),
        nullable=False,
        unique=True
    )

    user_name = db.Column(db.String(100), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    question_relevance = db.Column(db.String(50), nullable=False)
    agent_accuracy = db.Column(db.String(50), nullable=True)
    feedback_text = db.Column(db.Text, nullable=True)
    would_recommend = db.Column(db.Boolean, nullable=True)

    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    session = db.relationship(
        "InterviewSession",
        backref=db.backref(
            "agent_feedback",
            uselist=False,
            cascade="all, delete-orphan"
        )
    )