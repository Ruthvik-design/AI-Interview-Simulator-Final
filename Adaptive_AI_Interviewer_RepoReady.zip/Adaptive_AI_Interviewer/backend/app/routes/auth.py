from flask import Blueprint, jsonify, request

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json(silent=True) or {}
    username = str(data.get('username', '')).strip()
    role = str(data.get('role', 'user')).lower()
    password = str(data.get('password', '')).strip()

    if not username:
        return jsonify({"error": "Username is required"}), 400

    # If logging in as Admin Access
    if role == 'admin':
        if password != "AdminSecret123":
            return jsonify({"error": "Invalid Admin Security Key. Please try AdminSecret123"}), 401

    return jsonify({
        "success": True,
        "username": username,
        "role": role,
        "message": f"Logged in successfully as {role}"
    })