from flask import Blueprint, request, jsonify
from app.models.database import db, InterviewSession, ChatHistory

from app.services.interviewer_agent import InterviewerAgent
from app.services.evaluator_agent import EvaluatorAgent
from app.services.analytics_agent import AnalyticsAgent

from sqlalchemy import func
from datetime import datetime
import json

interview_bp = Blueprint('interview', __name__)


# ---------------------------------------------------------
# START INTERVIEW
# POST /api/interview/start
# ---------------------------------------------------------

@interview_bp.route('/start', methods=['POST'])
def start_interview():

    data = request.get_json(silent=True) or {}

    username = (
        data.get('username') or
        data.get('user_name') or
        'Candidate User'
    )

    role = data.get('role', 'Software Developer')
    experience = data.get('experience', 'Fresher (0-1 Yrs)')
    interview_type = data.get('interview_type', 'Technical + HR')

    try:
        time_limit = int(data.get('time_limit_minutes', 10))
    except (ValueError, TypeError):
        time_limit = 10

    time_limit = max(1, min(time_limit, 180))

    session = InterviewSession(
        user_name=username,
        role=role,
        experience=experience,
        interview_type=interview_type,
        time_limit_minutes=time_limit
    )

    try:
        db.session.add(session)
        db.session.commit()

        initial_question = InterviewerAgent.generate_next_question(
            session.role,
            session.experience,
            session.interview_type,
            []
        )

        if not initial_question:
            raise ValueError("AI interviewer returned an empty question.")

        chat = ChatHistory(
            session_id=session.id,
            sender='ai',
            message=initial_question
        )

        db.session.add(chat)
        db.session.commit()

        return jsonify({
            "success": True,
            "session_id": session.id,
            "question": initial_question,
            "time_limit_minutes": session.time_limit_minutes
        }), 201

    except Exception as error:

        db.session.rollback()

        print("[INTERVIEW START ERROR]", str(error))

        return jsonify({
            "success": False,
            "error": "Unable to start interview. Please try again."
        }), 500


# ---------------------------------------------------------
# RESPOND TO INTERVIEW
# POST /api/interview/respond
# ---------------------------------------------------------

@interview_bp.route('/respond', methods=['POST'])
def respond_interview():

    data = request.get_json(silent=True) or {}

    session_id = data.get('session_id')
    user_answer = data.get('answer')

    if not session_id or not isinstance(user_answer, str):
        return jsonify({
            "error": "Session ID and answer are required."
        }), 400

    user_answer = user_answer.strip()

    if not user_answer:
        return jsonify({
            "error": "Answer cannot be empty."
        }), 400

    session = db.session.get(InterviewSession, session_id)

    if not session:
        return jsonify({
            "error": "Interview session not found."
        }), 404

    if session.feedback_summary:
        return jsonify({
            "error": "This interview has already been completed."
        }), 400

    try:

        user_chat = ChatHistory(
            session_id=session.id,
            sender='user',
            message=user_answer
        )

        db.session.add(user_chat)
        db.session.commit()

        history_records = (
            ChatHistory.query
            .filter_by(session_id=session.id)
            .order_by(ChatHistory.timestamp.asc(), ChatHistory.id.asc())
            .all()
        )

        history = [
            {
                'sender': chat.sender,
                'message': chat.message
            }
            for chat in history_records
        ]

        next_question = InterviewerAgent.generate_next_question(
            session.role,
            session.experience,
            session.interview_type,
            history
        )

        if not next_question:
            raise ValueError("AI interviewer returned an empty question.")

        ai_chat = ChatHistory(
            session_id=session.id,
            sender='ai',
            message=next_question
        )

        db.session.add(ai_chat)
        db.session.commit()

        return jsonify({
            "success": True,
            "question": next_question
        }), 200

    except Exception as error:

        db.session.rollback()

        print("[INTERVIEW RESPONSE ERROR]", str(error))

        return jsonify({
            "success": False,
            "error": "Unable to generate the next question. Please try again."
        }), 500


# ---------------------------------------------------------
# COMPLETE INTERVIEW
# POST /api/interview/complete
# ---------------------------------------------------------

@interview_bp.route('/complete', methods=['POST'])
def complete_interview():

    data = request.get_json(silent=True) or {}

    session_id = data.get('session_id')

    if not session_id:
        return jsonify({
            "success": False,
            "error": "Session ID is required."
        }), 400

    session = db.session.get(InterviewSession, session_id)

    if not session:
        return jsonify({
            "success": False,
            "error": "Interview session not found."
        }), 404

    # Return existing evaluation instead of evaluating again.
    if session.feedback_summary:

        return jsonify({
            "success": True,
            "session_id": session.id,
            "evaluation": {
                "overall_score": session.overall_score or 0,
                "parameters": json.loads(
                    session.scores_json or '{}'
                ),
                "feedback_summary": session.feedback_summary,
                "areas_for_improvement": json.loads(
                    session.improvements_json or '{}'
                ).get('areas_for_improvement', []),
                "key_strengths": json.loads(
                    session.improvements_json or '{}'
                ).get('key_strengths', [])
            },
            "already_completed": True
        }), 200

    history_records = (
        ChatHistory.query
        .filter_by(session_id=session.id)
        .order_by(ChatHistory.timestamp.asc(), ChatHistory.id.asc())
        .all()
    )

    if not any(chat.sender == 'user' for chat in history_records):
        return jsonify({
            "success": False,
            "error": "Candidate has not submitted any answers."
        }), 400

    transcript = "\n".join([
        f"{'AI' if chat.sender == 'ai' else 'USER'}: {chat.message}"
        for chat in history_records
    ])

    try:

        # Evaluate the interview.
        evaluation = EvaluatorAgent.evaluate_interview(
            transcript,
            session.role,
            session.experience
        )

        if not isinstance(evaluation, dict):
            raise ValueError("Evaluator returned an invalid response.")

        required_fields = [
            'overall_score',
            'parameters',
            'feedback_summary',
            'areas_for_improvement',
            'key_strengths'
        ]

        missing_fields = [
            field for field in required_fields
            if field not in evaluation
        ]

        if missing_fields:
            raise ValueError(
                f"Missing evaluation fields: {missing_fields}"
            )

        # Save evaluation.
        session.overall_score = float(
            evaluation['overall_score']
        )

        session.scores_json = json.dumps(
            evaluation['parameters']
        )

        session.feedback_summary = str(
            evaluation['feedback_summary']
        )

        session.improvements_json = json.dumps({
            "areas_for_improvement":
                evaluation['areas_for_improvement'],

            "key_strengths":
                evaluation['key_strengths']
        })

        db.session.commit()

        # Compare only with previous completed attempts.
        past_sessions = (
            InterviewSession.query
            .filter(
                func.lower(InterviewSession.user_name) ==
                (session.user_name or '').lower(),

                InterviewSession.id != session.id,

                InterviewSession.feedback_summary.isnot(None)
            )
            .order_by(InterviewSession.created_at.asc())
            .all()
        )

        improvement_insights = AnalyticsAgent.compare_with_history(
            evaluation['parameters'],
            past_sessions
        )

        return jsonify({
            "success": True,
            "session_id": session.id,
            "evaluation": evaluation,
            "improvement_insights": improvement_insights
        }), 200

    except Exception as error:

        db.session.rollback()

        print("[INTERVIEW COMPLETION ERROR]", str(error))

        return jsonify({
            "success": False,
            "error": "Interview evaluation failed. Please try again."
        }), 500