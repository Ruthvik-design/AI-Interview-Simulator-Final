from flask import Blueprint, jsonify, request
from sqlalchemy import func
from collections import Counter, defaultdict
from datetime import datetime
import json

from app.models.database import (
    db,
    InterviewSession,
    ChatHistory,
    AgentFeedback
)

analytics_bp = Blueprint('analytics', __name__)


# ---------------------------------------------------------
# HELPER FUNCTIONS
# ---------------------------------------------------------

def safe_json(value, default=None):
    """
    Safely convert a JSON string into a Python object.
    Prevents malformed or empty database values from
    crashing the analytics endpoints.
    """
    if default is None:
        default = {}

    if not value:
        return default

    try:
        return json.loads(value)
    except (ValueError, TypeError):
        return default


def format_date(value):
    if not value:
        return "N/A"

    return value.strftime("%Y-%m-%d %H:%M")


def get_improvements(session):
    data = safe_json(session.improvements_json, {})

    if not isinstance(data, dict):
        data = {}

    strengths = data.get("key_strengths", [])
    improvements = data.get("areas_for_improvement", [])

    if not isinstance(strengths, list):
        strengths = []

    if not isinstance(improvements, list):
        improvements = []

    return strengths, improvements


def feedback_to_dict(feedback):
    if not feedback:
        return None

    session = feedback.session

    return {
        "id": feedback.id,
        "session_id": feedback.session_id,
        "username": feedback.user_name,
        "role": session.role if session else "N/A",
        "rating": feedback.rating,
        "question_relevance": feedback.question_relevance,
        "agent_accuracy": feedback.agent_accuracy,
        "feedback_text": feedback.feedback_text,
        "would_recommend": feedback.would_recommend,
        "date": format_date(feedback.created_at)
    }


def session_to_dict(session, include_transcript=False):
    strengths, improvements = get_improvements(session)

    result = {
        "id": session.id,
        "user_name": session.user_name or "Candidate User",
        "role": session.role,
        "experience": session.experience,
        "interview_type": session.interview_type,
        "date": format_date(session.created_at),
        "overall_score": session.overall_score or 0,
        "scores": safe_json(session.scores_json, {}),
        "feedback": session.feedback_summary or "",
        "areas_for_improvement": improvements,
        "key_strengths": strengths,
        "agent_feedback": feedback_to_dict(
            getattr(session, "agent_feedback", None)
        )
    }

    if include_transcript:
        chats = (
            ChatHistory.query
            .filter_by(session_id=session.id)
            .order_by(ChatHistory.timestamp.asc())
            .all()
        )

        result["transcript"] = [
            {
                "sender": chat.sender,
                "message": chat.message,
                "time": (
                    chat.timestamp.strftime("%H:%M:%S")
                    if chat.timestamp else "N/A"
                )
            }
            for chat in chats
        ]

    return result


def is_completed(session):
    return bool(
        session.feedback_summary and
        str(session.feedback_summary).strip()
    )


# ---------------------------------------------------------
# CANDIDATE INTERVIEW HISTORY
# GET /api/analytics/history?username=<username>
# ---------------------------------------------------------

@analytics_bp.route('/history', methods=['GET'])
def get_history():
    username = request.args.get('username', '').strip()

    query = InterviewSession.query

    if username and username.lower() not in ["undefined", "null"]:
        query = query.filter(
            func.lower(InterviewSession.user_name) == username.lower()
        )

    sessions = (
        query
        .order_by(InterviewSession.created_at.desc())
        .all()
    )

    results = [
        session_to_dict(session)
        for session in sessions
    ]

    return jsonify(results), 200


# ---------------------------------------------------------
# ADMIN: ALL INTERVIEW RECORDS
# GET /api/analytics/admin/all-interviews
# ---------------------------------------------------------

@analytics_bp.route('/admin/all-interviews', methods=['GET'])
def admin_all_interviews():
    sessions = (
        InterviewSession.query
        .order_by(InterviewSession.created_at.desc())
        .all()
    )

    results = [
        session_to_dict(session, include_transcript=True)
        for session in sessions
    ]

    return jsonify(results), 200


# ---------------------------------------------------------
# ADMIN: OVERALL CANDIDATE ANALYTICS
# GET /api/analytics/admin/overview
# ---------------------------------------------------------

@analytics_bp.route('/admin/overview', methods=['GET'])
def admin_overview():

    sessions = (
        InterviewSession.query
        .order_by(InterviewSession.created_at.asc())
        .all()
    )

    candidates_data = defaultdict(list)

    completed_sessions = [
        session for session in sessions
        if is_completed(session)
    ]

    all_strengths = Counter()
    all_improvements = Counter()

    for session in sessions:
        username = (session.user_name or "Candidate User").strip()

        candidates_data[username.lower()].append(session)

        strengths, improvements = get_improvements(session)

        for item in strengths:
            if isinstance(item, str) and item.strip():
                all_strengths[item.strip()] += 1

        for item in improvements:
            if isinstance(item, str) and item.strip():
                all_improvements[item.strip()] += 1

    candidates = []

    for username_key, candidate_sessions in candidates_data.items():

        candidate_sessions.sort(
            key=lambda item: item.created_at or datetime.min
        )

        completed = [
            session for session in candidate_sessions
            if is_completed(session)
        ]

        scores = [
            float(session.overall_score or 0)
            for session in completed
        ]

        average_score = (
            sum(scores) / len(scores)
            if scores else 0
        )

        first_score = scores[0] if scores else 0
        latest_score = scores[-1] if scores else 0

        if len(scores) < 2:
            progress = "Not enough data"
        elif latest_score > first_score:
            progress = "Improving"
        elif latest_score < first_score:
            progress = "Needs Improvement"
        else:
            progress = "Consistent"

        roles = Counter(
            session.role
            for session in candidate_sessions
            if session.role
        )

        candidate_strengths = Counter()
        candidate_improvements = Counter()

        for session in candidate_sessions:
            strengths, improvements = get_improvements(session)

            candidate_strengths.update(
                item for item in strengths
                if isinstance(item, str) and item.strip()
            )

            candidate_improvements.update(
                item for item in improvements
                if isinstance(item, str) and item.strip()
            )

        display_username = (
            candidate_sessions[-1].user_name or "Candidate User"
        )

        candidates.append({
            "username": display_username,
            "total_interviews": len(candidate_sessions),
            "completed_interviews": len(completed),
            "average_score": round(average_score, 2),
            "first_score": round(first_score, 2),
            "latest_score": round(latest_score, 2),
            "progress": progress,
            "roles": dict(roles),
            "key_strengths": [
                name for name, count in candidate_strengths.most_common(10)
            ],
            "areas_for_improvement": [
                name for name, count in candidate_improvements.most_common(10)
            ],
            "last_interview": format_date(
                candidate_sessions[-1].created_at
            )
        })

    candidates.sort(
        key=lambda item: item["username"].lower()
    )

    completed_scores = [
        float(session.overall_score or 0)
        for session in completed_sessions
    ]

    overall_average = (
        sum(completed_scores) / len(completed_scores)
        if completed_scores else 0
    )

    return jsonify({
        "total_candidates": len(candidates),
        "total_interviews": len(sessions),
        "completed_interviews": len(completed_sessions),
        "average_candidate_score": round(overall_average, 2),
        "candidates": candidates,
        "most_common_strengths": [
            {
                "name": name,
                "count": count
            }
            for name, count in all_strengths.most_common(8)
        ],
        "most_common_improvements": [
            {
                "name": name,
                "count": count
            }
            for name, count in all_improvements.most_common(8)
        ]
    }), 200


# ---------------------------------------------------------
# CANDIDATE: SUBMIT AI AGENT FEEDBACK
# POST /api/analytics/feedback
# ---------------------------------------------------------

@analytics_bp.route('/feedback', methods=['POST'])
def submit_agent_feedback():

    data = request.get_json(silent=True) or {}

    session_id = data.get("session_id")
    username = str(data.get("username", "")).strip()
    rating = data.get("rating")
    question_relevance = data.get("question_relevance")
    agent_accuracy = data.get("agent_accuracy")
    feedback_text = data.get("feedback_text", "")
    would_recommend = data.get("would_recommend")

    # Required fields
    if not session_id or not username:
        return jsonify({
            "error": "Session ID and username are required."
        }), 400

    # Validate rating
    try:
        rating = int(rating)
    except (ValueError, TypeError):
        return jsonify({
            "error": "Rating must be an integer between 1 and 5."
        }), 400

    if rating < 1 or rating > 5:
        return jsonify({
            "error": "Rating must be between 1 and 5."
        }), 400

    # Validate question relevance
    allowed_relevance = [
        "Very relevant",
        "Mostly relevant",
        "Not relevant"
    ]

    if question_relevance not in allowed_relevance:
        return jsonify({
            "error": "Invalid question relevance value."
        }), 400

    # Validate AI accuracy
    allowed_accuracy = [
        "Very accurate",
        "Mostly accurate",
        "Needs improvement"
    ]

    if agent_accuracy not in allowed_accuracy:
        agent_accuracy = None

    # Validate comments
    if feedback_text is None:
        feedback_text = ""

    if not isinstance(feedback_text, str):
        return jsonify({
            "error": "Feedback comments must be text."
        }), 400

    feedback_text = feedback_text.strip()

    if len(feedback_text) > 3000:
        return jsonify({
            "error": "Feedback cannot exceed 3000 characters."
        }), 400

    # Validate recommendation
    if would_recommend not in [True, False, None]:
        return jsonify({
            "error": "Invalid recommendation value."
        }), 400

    # Find interview session
    session = db.session.get(InterviewSession, session_id)

    if not session:
        return jsonify({
            "error": "Interview session not found."
        }), 404

    # Confirm that feedback belongs to the candidate's session.
    session_username = (session.user_name or "").strip().lower()

    if session_username != username.lower():
        return jsonify({
            "error": "You cannot submit feedback for another candidate's interview."
        }), 403

    # Feedback can only be submitted after evaluation.
    if not is_completed(session):
        return jsonify({
            "error": "Complete the interview before submitting feedback."
        }), 400

    # One feedback submission per interview.
    existing_feedback = AgentFeedback.query.filter_by(
        session_id=session_id
    ).first()

    if existing_feedback:
        return jsonify({
            "error": "Feedback has already been submitted for this interview."
        }), 409

    feedback = AgentFeedback(
        session_id=session_id,
        user_name=session.user_name or username,
        rating=rating,
        question_relevance=question_relevance,
        agent_accuracy=agent_accuracy,
        feedback_text=feedback_text,
        would_recommend=would_recommend
    )

    try:
        db.session.add(feedback)
        db.session.commit()

        return jsonify({
            "success": True,
            "message": "AI interviewer feedback submitted successfully.",
            "feedback": feedback_to_dict(feedback)
        }), 201

    except Exception as error:
        db.session.rollback()

        print("Feedback submission error:", error)

        return jsonify({
            "error": "Unable to save feedback. Please try again."
        }), 500


# ---------------------------------------------------------
# ADMIN: AI AGENT FEEDBACK ANALYTICS
# GET /api/analytics/admin/agent-feedback
# ---------------------------------------------------------

@analytics_bp.route('/admin/agent-feedback', methods=['GET'])
def admin_agent_feedback():

    feedback_records = (
        AgentFeedback.query
        .order_by(AgentFeedback.created_at.desc())
        .all()
    )

    total_responses = len(feedback_records)

    average_rating = (
        sum(item.rating for item in feedback_records) /
        total_responses
        if total_responses else 0
    )

    recommendation_records = [
        item for item in feedback_records
        if item.would_recommend is not None
    ]

    recommendation_rate = (
        sum(
            1 for item in recommendation_records
            if item.would_recommend is True
        ) / len(recommendation_records) * 100
        if recommendation_records else 0
    )

    relevance_counter = Counter(
        item.question_relevance
        for item in feedback_records
        if item.question_relevance
    )

    feedback_list = [
        feedback_to_dict(item)
        for item in feedback_records
    ]

    return jsonify({
        "total_responses": total_responses,
        "average_rating": round(average_rating, 2),
        "recommendation_rate": round(recommendation_rate, 2),
        "relevance_breakdown": dict(relevance_counter),
        "feedback": feedback_list
    }), 200


# ---------------------------------------------------------
# ADMIN: DELETE INTERVIEW AND ASSOCIATED DATA
# DELETE /api/analytics/admin/interview/<session_id>
# ---------------------------------------------------------

@analytics_bp.route(
    '/admin/interview/<int:session_id>',
    methods=['DELETE']
)
def admin_delete_interview(session_id):

    session = db.session.get(InterviewSession, session_id)

    if not session:
        return jsonify({
            "error": "Interview session not found."
        }), 404

    try:
        # Delete transcript records.
        ChatHistory.query.filter_by(
            session_id=session_id
        ).delete(synchronize_session=False)

        # Delete candidate feedback.
        AgentFeedback.query.filter_by(
            session_id=session_id
        ).delete(synchronize_session=False)

        # Delete interview session.
        db.session.delete(session)

        db.session.commit()

        return jsonify({
            "success": True,
            "message": "Interview and associated feedback deleted successfully."
        }), 200

    except Exception as error:
        db.session.rollback()

        print("Interview deletion error:", error)

        return jsonify({
            "error": "Unable to delete interview."
        }), 500