from flask import Flask
from flask_cors import CORS
from app.config import Config
from app.models.database import db
from app.routes.auth import auth_bp
from app.routes.interview import interview_bp
from app.routes.analytics import analytics_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    CORS(app)
    db.init_app(app)
    
    with app.app_context():
        db.create_all()
        
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(interview_bp, url_prefix='/api/interview')
    app.register_blueprint(analytics_bp, url_prefix='/api/analytics')
    
    return app
