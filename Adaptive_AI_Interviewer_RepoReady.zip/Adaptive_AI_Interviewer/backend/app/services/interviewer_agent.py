
import requests
import re
from app.config import Config


class InterviewerAgent:

    # ==================================================
    # ROLE-SPECIFIC TECHNICAL TOPICS
    # ==================================================

    ROLE_TOPICS = {
        "full stack": [
            "HTML, CSS and JavaScript",
            "frontend frameworks and component development",
            "Python or JavaScript backend development",
            "REST APIs and frontend-backend integration",
            "SQL and database operations",
            "authentication and authorization",
            "application testing and debugging",
            "deployment and application performance"
        ],

        "software developer": [
            "programming fundamentals",
            "data structures and algorithms",
            "object-oriented programming",
            "software development lifecycle",
            "database management",
            "API development",
            "debugging and testing",
            "system design appropriate to experience"
        ],

        "frontend": [
            "HTML and CSS",
            "JavaScript fundamentals",
            "React or frontend framework concepts",
            "component lifecycle and state management",
            "API integration",
            "responsive design",
            "browser debugging and optimization"
        ],

        "backend": [
            "Python or backend programming",
            "REST API development",
            "database design and SQL",
            "authentication and authorization",
            "server-side validation",
            "error handling",
            "testing and performance"
        ],

        "data scientist": [
            "Python and data manipulation",
            "NumPy and pandas",
            "exploratory data analysis",
            "statistical concepts",
            "feature engineering",
            "machine learning algorithms",
            "model evaluation",
            "model deployment"
        ],

        "machine learning": [
            "Python and machine learning libraries",
            "supervised and unsupervised learning",
            "data preprocessing",
            "feature selection",
            "model training and validation",
            "overfitting and regularization",
            "evaluation metrics",
            "model deployment"
        ],

        "data engineer": [
            "Python and SQL",
            "database concepts",
            "ETL and ELT pipelines",
            "data warehousing",
            "data cleaning and validation",
            "Apache Spark and distributed processing",
            "pipeline scheduling",
            "data quality and monitoring"
        ],

        "devops": [
            "Linux fundamentals",
            "Git and version control",
            "CI/CD pipelines",
            "Docker and containerization",
            "cloud infrastructure",
            "Kubernetes fundamentals",
            "monitoring and deployment"
        ],

        "business analyst": [
            "requirement gathering",
            "business process analysis",
            "SQL and data analysis",
            "stakeholder communication",
            "business intelligence",
            "reporting and dashboards",
            "problem-solving and documentation"
        ],

        "cybersecurity": [
            "network security",
            "authentication and access control",
            "common security vulnerabilities",
            "encryption fundamentals",
            "incident response",
            "security monitoring",
            "risk assessment"
        ]
    }

    # ==================================================
    # EXPERIENCE-BASED DIFFICULTY
    # ==================================================

    EXPERIENCE_LEVELS = {
        "fresher": """
        Difficulty: Beginner to intermediate.
        Focus on fundamentals, basic implementation,
        academic projects and practical understanding.
        Avoid advanced production architecture unless
        the candidate demonstrates sufficient knowledge.
        """,

        "mid": """
        Difficulty: Intermediate.
        Focus on implementation, debugging,
        practical scenarios, optimization and
        independent technical decisions.
        """,

        "senior": """
        Difficulty: Advanced.
        Focus on architecture, scalability,
        technical leadership, optimization,
        production decisions and trade-offs.
        """
    }

    # ==================================================
    # INTERVIEW TYPE RULES
    # ==================================================

    INTERVIEW_TYPES = {
        "technical": """
        Ask technical questions only.
        Focus on programming, tools, concepts,
        implementation and problem-solving.
        """,

        "hr": """
        Ask HR and behavioral questions only.
        Focus on communication, teamwork,
        motivation, adaptability and challenges.
        """,

        "mixed": """
        Conduct a balanced Technical + HR interview.
        Most questions should assess technical skills.
        Include relevant behavioral questions at
        appropriate intervals.
        """
    }

    # ==================================================
    # ROLE MATCHING
    # ==================================================

    @staticmethod
    def get_role_topics(role):

        role_lower = role.lower()

        for keyword, topics in InterviewerAgent.ROLE_TOPICS.items():

            if keyword in role_lower:
                return topics

        return [
            f"{role} fundamentals",
            f"Core tools and technologies used in {role}",
            f"Practical implementation in {role}",
            f"Problem-solving related to {role}",
            f"Debugging and troubleshooting in {role}",
            f"Real-world applications of {role}"
        ]

    # ==================================================
    # EXPERIENCE MATCHING
    # ==================================================

    @staticmethod
    def get_experience_level(experience):

        exp = experience.lower()

        if any(word in exp for word in ["fresher", "0-1", "entry"]):
            return InterviewerAgent.EXPERIENCE_LEVELS["fresher"]

        if any(word in exp for word in ["mid", "2-4", "intermediate"]):
            return InterviewerAgent.EXPERIENCE_LEVELS["mid"]

        if any(word in exp for word in ["senior", "5+", "experienced"]):
            return InterviewerAgent.EXPERIENCE_LEVELS["senior"]

        return InterviewerAgent.EXPERIENCE_LEVELS["fresher"]

    # ==================================================
    # INTERVIEW TYPE MATCHING
    # ==================================================

    @staticmethod
    def get_interview_type_rules(interview_type):

        interview = interview_type.lower()

        if "technical + hr" in interview or "technical and hr" in interview:
            return InterviewerAgent.INTERVIEW_TYPES["mixed"]

        if "hr" in interview or "behavioral" in interview:
            return InterviewerAgent.INTERVIEW_TYPES["hr"]

        return InterviewerAgent.INTERVIEW_TYPES["technical"]

    # ==================================================
    # EXTRACT LATEST CANDIDATE ANSWER
    # ==================================================

    @staticmethod
    def get_last_candidate_answer(chat_history):

        for chat in reversed(chat_history):

            if chat.get("sender", "").lower() in ["user", "candidate"]:

                return chat.get("message", "").strip()

        return ""

    # ==================================================
    # NORMALIZE QUESTION
    # ==================================================

    @staticmethod
    def normalize_question(question):

        question = question.lower().strip()

        question = re.sub(
            r"[^a-z0-9\s]",
            "",
            question
        )

        return re.sub(r"\s+", " ", question)

    # ==================================================
    # OPENING QUESTION
    # ==================================================

    @staticmethod
    def get_opening_question(role, experience, interview_type):

        interview = interview_type.lower()
        role_lower = role.lower()

        if "hr" in interview and "technical" not in interview:

            return (
                f"Could you introduce yourself and explain "
                f"why you are interested in the {role} position?"
            )

        if "data scientist" in role_lower:

            return (
                "Could you introduce yourself and describe a "
                "data science or machine learning project you have worked on?"
            )

        if "machine learning" in role_lower:

            return (
                "Could you introduce yourself and explain a machine learning "
                "project you have developed, including the problem it solved?"
            )

        if "data engineer" in role_lower:

            return (
                "Could you introduce yourself and describe your experience "
                "working with data processing, databases or ETL pipelines?"
            )

        if "full stack" in role_lower:

            return (
                "Could you introduce yourself and describe a web application "
                "you have developed, including the technologies you used?"
            )

        return (
            f"Could you introduce yourself and describe a project or practical "
            f"experience related to {role}?"
        )

    # ==================================================
    # IMPROVED CONTEXTUAL FALLBACK QUESTION
    # ==================================================

    @staticmethod
    def get_fallback_question(
        role,
        experience,
        interview_type,
        last_answer,
        previous_questions
    ):

        """
        Generate a contextual question using the candidate's
        latest answer instead of automatically moving to
        the next predefined topic.
        """

        if last_answer:

            answer = last_answer.strip()

            technologies = [
                "React",
                "JavaScript",
                "HTML",
                "CSS",
                "Python",
                "Java",
                "SQL",
                "MongoDB",
                "Flask",
                "Django",
                "FastAPI",
                "Node.js",
                "REST API",
                "API",
                "Machine Learning",
                "TensorFlow",
                "PyTorch",
                "Docker"
            ]

            mentioned = [
                tech for tech in technologies
                if re.search(
                    r"\b" + re.escape(tech) + r"\b",
                    answer,
                    re.IGNORECASE
                )
            ]

            # Explore a technology explicitly mentioned
            if mentioned:

                technology = mentioned[0]

                question = (
                    f"You mentioned {technology}. "
                    f"Can you explain how you used {technology} "
                    f"in your project and one challenge you faced?"
                )

            else:

                # Explore the candidate's actual explanation
                short_answer = answer[:100]

                question = (
                    f"You mentioned that {short_answer}. "
                    f"Could you explain how you implemented this "
                    f"in a practical project related to {role}?"
                )

        else:

            question = (
                f"Can you describe a practical challenge "
                f"related to {role} and how you would solve it?"
            )

        # Prevent returning an exact duplicate
        normalized_question = (
            InterviewerAgent.normalize_question(question)
        )

        normalized_previous = [
            InterviewerAgent.normalize_question(q)
            for q in previous_questions
        ]

        if normalized_question in normalized_previous:

            question = (
                f"Can you describe one practical example "
                f"related to your previous answer and explain "
                f"how you approached it?"
            )

        return question

    # ==================================================
    # GENERATE NEXT ADAPTIVE QUESTION
    # ==================================================

    @staticmethod
    def generate_next_question(
        role,
        experience,
        interview_type,
        chat_history
    ):

        url = f"{Config.OLLAMA_BASE_URL}/api/generate"

        # First question
        if not chat_history:

            return InterviewerAgent.get_opening_question(
                role,
                experience,
                interview_type
            )

        # Previous AI questions
        previous_questions = [
            chat.get("message", "").strip()
            for chat in chat_history
            if chat.get("sender", "").lower() == "ai"
        ]

        # Latest candidate answer
        last_user_answer = (
            InterviewerAgent.get_last_candidate_answer(
                chat_history
            )
        )

        # Role-specific topics
        role_topics = InterviewerAgent.get_role_topics(role)

        # Experience difficulty
        difficulty_rules = (
            InterviewerAgent.get_experience_level(experience)
        )

        # Interview type
        interview_rules = (
            InterviewerAgent.get_interview_type_rules(
                interview_type
            )
        )

        # Format entire conversation
        formatted_dialogue = ""

        for chat in chat_history:

            sender = chat.get("sender", "").lower()

            speaker = (
                "INTERVIEWER"
                if sender == "ai"
                else "CANDIDATE"
            )

            formatted_dialogue += (
                f"{speaker}: {chat.get('message', '')}\n"
            )

        # ==================================================
        # ADAPTIVE PROMPT
        # ==================================================

        system_instruction = f"""
You are a professional human interviewer conducting
a realistic adaptive job interview.

CANDIDATE DETAILS:

Job Role: {role}
Experience Level: {experience}
Interview Type: {interview_type}

STRICT ROLE RELEVANCE:

Every technical question MUST be directly relevant
to the selected job role.

Do not ask unrelated technical questions.

APPROVED ROLE TOPICS:

{', '.join(role_topics)}

EXPERIENCE RULES:

{difficulty_rules}

INTERVIEW TYPE RULES:

{interview_rules}

ADAPTIVE FOLLOW-UP RULES:

1. Carefully understand the candidate's latest answer.

2. Identify the actual technologies, concepts, projects
   or skills mentioned in that answer.

3. The next question MUST use information from the
   candidate's latest answer whenever possible.

4. If the candidate mentions a project, explore its
   architecture, technologies, implementation,
   challenges and results one step at a time.

5. If the candidate mentions a technology,
   ask a relevant question about that technology.

6. If the candidate gives an incomplete answer,
   ask a clarifying question.

7. If the candidate gives a correct answer,
   gradually increase the difficulty.

8. If the candidate gives an incorrect answer,
   ask a simpler related question to assess understanding.

9. If the candidate gives a very short or vague answer,
   ask them to elaborate.

10. Never assume the candidate has used a technology
    unless they explicitly mention it.

11. Avoid repeating previously asked questions.

12. Maintain a natural conversation like a real interviewer.

13. Ask ONLY ONE question at a time.

14. Keep questions concise and understandable.

15. For freshers, prefer fundamentals and practical
    project-based questions.

16. Do not automatically move to another predefined
    topic after every candidate response.

17. Prefer a meaningful follow-up to the latest answer
    over a generic question from the topic list.

LATEST CANDIDATE ANSWER:

{last_user_answer}

IMPORTANT:

Use the complete conversation to understand the interview.

Your next question must be connected to the candidate's
latest answer and the selected job role.

Do not simply select the next topic from the approved list.

OUTPUT FORMAT:

Return ONLY the next interview question.

Do not include explanations, question numbers,
evaluation, greetings or multiple questions.
"""

        full_prompt = f"""
{system_instruction}

COMPLETE INTERVIEW CONVERSATION:

{formatted_dialogue}

INTERVIEWER: Ask the next relevant adaptive question:
"""

        # ==================================================
        # DEBUG INFORMATION
        # ==================================================

        print("\n========== OLLAMA DEBUG ==========")
        print("Role:", role)
        print("Experience:", experience)
        print("Interview Type:", interview_type)
        print("Latest Candidate Answer:", last_user_answer)
        print("Previous Questions:", previous_questions)
        print("Sending adaptive prompt to Ollama...")
        print("=================================\n")

        # ==================================================
        # OLLAMA REQUEST
        # ==================================================

        payload = {
            "model": Config.OLLAMA_MODEL,
            "prompt": full_prompt,
            "stream": False,
            "options": {
                "temperature": 0.35,
                "top_p": 0.85,
                "repeat_penalty": 1.25,
                "num_predict": 120
            }
        }

        try:

            response = requests.post(
                url,
                json=payload,
                timeout=120
            )

            response.raise_for_status()

            response_data = response.json()

            question = response_data.get(
                "response", ""
            ).strip()

            # Clean common model output prefixes
            question = re.sub(
                r"^(INTERVIEWER|NEXT QUESTION)\s*:\s*",
                "",
                question,
                flags=re.IGNORECASE
            ).strip()

            question = question.strip('"\'` ')

            # Validate generated question
            if (
                question
                and len(question) > 15
                and "?" in question
            ):

                normalized_question = (
                    InterviewerAgent.normalize_question(
                        question
                    )
                )

                normalized_previous = [
                    InterviewerAgent.normalize_question(q)
                    for q in previous_questions
                ]

                if normalized_question not in normalized_previous:

                    print(
                        f"[AI INTERVIEWER] Ollama generated: {question}"
                    )

                    return question

                print(
                    "[AI INTERVIEWER] Duplicate question detected."
                )

            else:

                print(
                    "[AI INTERVIEWER] Invalid question generated."
                )

        except requests.exceptions.Timeout:

            print(
                "[AI INTERVIEWER] Ollama request timed out."
            )

        except requests.exceptions.ConnectionError:

            print(
                "[AI INTERVIEWER] Cannot connect to Ollama."
            )

        except Exception as error:

            print(
                f"[AI INTERVIEWER ERROR] {str(error)}"
            )

        # ==================================================
        # CONTEXTUAL FALLBACK
        # ==================================================

        fallback = InterviewerAgent.get_fallback_question(
            role,
            experience,
            interview_type,
            last_user_answer,
            previous_questions
        )

        print(
            f"[AI INTERVIEWER] Using contextual fallback: {fallback}"
        )

        return fallback
