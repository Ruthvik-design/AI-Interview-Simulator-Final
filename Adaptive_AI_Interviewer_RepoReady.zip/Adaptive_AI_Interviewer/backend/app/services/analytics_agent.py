import json

class AnalyticsAgent:
    @staticmethod
    def compare_with_history(current_scores, past_sessions):
        if not past_sessions:
            return "This is your baseline interview attempt! Future attempts will track progress automatically."
            
        last_session = past_sessions[-1]
        last_scores = json.loads(last_session.scores_json) if last_session.scores_json else {}
        
        improvements = []
        declines = []
        
        for param, current_val in current_scores.items():
            prev_val = last_scores.get(param, current_val)
            diff = round(current_val - prev_val, 1)
            if diff > 0:
                improvements.append(f"{param} increased by +{diff} pts.")
            elif diff < 0:
                declines.append(f"{param} changed by {diff} pts.")
            else:
                improvements.append(f"{param} remained steady at {current_val}.")
                
        summary_text = " ".join(improvements) + (" " + " ".join(declines) if declines else "")
        return summary_text
