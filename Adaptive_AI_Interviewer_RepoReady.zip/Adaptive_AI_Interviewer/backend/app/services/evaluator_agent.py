
import requests
import json
import re
from app.config import Config


class EvaluatorAgent:

    @staticmethod
    def evaluate_interview(transcript, role, experience):

        if not transcript or not transcript.strip():
            raise ValueError("Interview transcript is empty. Cannot evaluate.")

        url = f"{Config.OLLAMA_BASE_URL}/api/generate"

        prompt = f"""
You are an experienced technical interviewer and candidate performance evaluator.

Evaluate ONLY the candidate's actual answers in the transcript.

CANDIDATE DETAILS:
Target Role: {role}
Experience Level: {experience}

INTERVIEW TRANSCRIPT:
{transcript}

IMPORTANT EVALUATION RULES:

1. Read every interviewer question and the corresponding candidate answer.
2. Evaluate technical accuracy, not merely answer length.
3. Identify what the candidate actually explained correctly.
4. Identify concepts the candidate misunderstood or failed to explain.
5. Consider the candidate's experience level.
6. Give feedback specific to the actual answers.
7. Do not invent skills, projects, tools or achievements.
8. Do not use generic statements such as "improve technical knowledge".
9. Never copy a predefined feedback template.
10. Do not give identical feedback for different transcripts.
11. If an answer is incorrect, explain the actual mistake.
12. If an answer is incomplete, identify what is missing.
13. Do not reward long answers unless they demonstrate understanding.
14. Evaluate communication based on clarity and structure.

SCORING:
Give scores from 0 to 10 for:

- Relevance
- Completeness
- Clarity
- Technical Understanding
- Communication

Calculate overall_score as the average of these five scores.

Return ONLY valid JSON in this exact structure:

{{
  "overall_score": 7.2,
  "parameters": {{
    "Relevance": 7.0,
    "Completeness": 7.0,
    "Clarity": 8.0,
    "Technical Understanding": 6.5,
    "Communication": 7.5
  }},
  "feedback_summary": "A detailed summary based on the actual interview answers.",
  "areas_for_improvement": [
    "Mention a specific concept from the candidate's answer that needs improvement.",
    "Explain what the candidate should have included."
  ],
  "key_strengths": [
    "Mention a specific concept correctly explained by the candidate.",
    "Identify another demonstrated strength."
  ]
}}

Return 2 to 5 specific improvements and 2 to 5 specific strengths.
If the transcript does not provide enough evidence for a particular skill,
state that evidence was insufficient instead of inventing an assessment.
"""

        payload = {
            "model": Config.OLLAMA_MODEL,
            "prompt": prompt,
            "stream": False,
            "format": "json",
            "options": {
                "temperature": 0.2,
                "top_p": 0.9
            }
        }

        try:

            response = requests.post(
                url,
                json=payload,
                timeout=180
            )

            response.raise_for_status()

            response_data = response.json()

            raw_output = response_data.get("response", "").strip()

            if not raw_output:
                raise ValueError("Ollama returned an empty evaluation.")

            # Extract JSON safely
            try:
                evaluation = json.loads(raw_output)

            except json.JSONDecodeError:

                match = re.search(
                    r"\{.*\}",
                    raw_output,
                    re.DOTALL
                )

                if not match:
                    raise ValueError(
                        "Ollama did not return valid JSON."
                    )

                evaluation = json.loads(match.group(0))

            required_parameters = [
                "Relevance",
                "Completeness",
                "Clarity",
                "Technical Understanding",
                "Communication"
            ]

            parameters = evaluation.get("parameters", {})

            for parameter in required_parameters:

                if parameter not in parameters:
                    raise ValueError(
                        f"Missing evaluation parameter: {parameter}"
                    )

                score = float(parameters[parameter])

                if not 0 <= score <= 10:
                    raise ValueError(
                        f"Invalid score for {parameter}"
                    )

                parameters[parameter] = round(score, 1)

            overall_score = round(
                sum(parameters.values()) /
                len(required_parameters),
                1
            )

            summary = evaluation.get(
                "feedback_summary", ""
            )

            improvements = evaluation.get(
                "areas_for_improvement", []
            )

            strengths = evaluation.get(
                "key_strengths", []
            )

            if not summary or not isinstance(summary, str):
                raise ValueError("Missing evaluation summary.")

            if not isinstance(improvements, list):
                raise ValueError("Invalid improvements format.")

            if not isinstance(strengths, list):
                raise ValueError("Invalid strengths format.")

            improvements = [
                str(item).strip()
                for item in improvements
                if str(item).strip()
            ]

            strengths = [
                str(item).strip()
                for item in strengths
                if str(item).strip()
            ]

            if not improvements or not strengths:
                raise ValueError(
                    "Evaluation must contain strengths and improvements."
                )

            return {
                "overall_score": overall_score,
                "parameters": parameters,
                "feedback_summary": summary,
                "areas_for_improvement": improvements,
                "key_strengths": strengths
            }

        except Exception as error:

            print(
                f"[EVALUATOR ERROR] {str(error)}"
            )

            # Do not save fabricated or randomized evaluations.
            raise RuntimeError(
                "AI evaluation failed. Please check Ollama and try again. "
                + str(error)
            )
