# Adaptive AI Interviewer (Ollama Local)

A web-based mock interview platform that uses a locally hosted Ollama language model to ask role-aware interview questions, follow up on candidate responses, evaluate the completed transcript, and display interview history.

## Features

- Candidate and administrator entry screens.
- Interview configuration by job role, experience level, interview type, and time limit.
- Adaptive question generation using conversation history and role-specific topic guidance.
- Local LLM inference through Ollama (`llama3.2:3b` by default).
- Transcript persistence with Flask-SQLAlchemy and SQLite.
- AI-generated evaluation with five score dimensions: relevance, completeness, clarity, technical understanding, and communication.
- Candidate interview history and administrator transcript review.
- Time-limit handling in the browser and automatic interview completion.

## Technology stack

| Layer | Technologies |
|---|---|
| Frontend | React 18, Vite, Tailwind CSS, Axios, Lucide React |
| Backend | Python, Flask, Flask-CORS, Flask-SQLAlchemy |
| Local AI | Ollama HTTP API, `llama3.2:3b` |
| Database | SQLite |
| Configuration | `python-dotenv`, environment variables |

## Architecture

```mermaid
flowchart TD
    C[Candidate / Admin] --> UI[React + Vite UI]
    UI --> API[Axios API service]
    API --> FLASK[Flask REST API]
    FLASK --> AUTH[Authentication route]
    FLASK --> INT[Interview route]
    FLASK --> ANA[Analytics route]
    INT --> IA[InterviewerAgent]
    INT --> EA[EvaluatorAgent]
    INT --> AA[AnalyticsAgent]
    IA --> O[Ollama API :11434]
    EA --> O
    AUTH --> DB[(SQLite via SQLAlchemy)]
    INT --> DB
    ANA --> DB
    AA --> DB
```

Detailed flow and design notes are in [System Architecture and Code Flow](docs/ARCHITECTURE_AND_CODE_FLOW.md).

## Repository structure

```text
Adaptive_AI_Interviewer/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── config.py
│   │   ├── models/database.py
│   │   ├── routes/                 # auth, interview, analytics APIs
│   │   └── services/               # interviewer, evaluator, analytics agents
│   ├── .env.example
│   ├── requirements.txt
│   └── run.py
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/                  # Login, Setup, Interview, Dashboard, Admin
│   │   └── services/api.js
│   ├── package.json
│   └── vite.config.js
└── docs/
    ├── ARCHITECTURE_AND_CODE_FLOW.md
    ├── TEST_CASES.md
    └── screenshots/
```

## Prerequisites

- Python 3.10 or newer
- Node.js 18 or newer and npm
- Ollama installed and running
- The model pulled locally: `ollama pull llama3.2:3b`

## Setup and run (Windows PowerShell)

### 1. Start Ollama

Open a terminal and run:

```powershell
ollama serve
```

In another terminal, verify the model is installed:

```powershell
ollama list
ollama run llama3.2:3b "Reply with: Ollama is ready"
```

### 2. Start the Flask backend

```powershell
cd backend
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
python run.py
```

The backend runs at `http://127.0.0.1:5000` by default. The Ollama endpoint is configured in `backend/.env`.

### 3. Start the React frontend

Open another terminal:

```powershell
cd frontend
npm ci
npm run dev
```

Open the Vite URL printed in the terminal (normally `http://localhost:3000` or `http://localhost:5173`, depending on `vite.config.js`).

## Environment variables

Set these in `backend/.env` (do not commit `.env`):

```env
OLLAMA_BASE_URL=http://127.0.0.1:11434
OLLAMA_MODEL=llama3.2:3b
JWT_SECRET_KEY=replace-with-a-long-random-secret
DATABASE_URI=sqlite:///interview_simulator.db
PORT=5000
```

## API overview

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/login` | Candidate/admin entry request |
| POST | `/api/interview/start` | Create session and opening question |
| POST | `/api/interview/respond` | Save answer and generate next question |
| POST | `/api/interview/complete` | Evaluate transcript and save result |
| GET | `/api/analytics/history?username=<name>` | Retrieve interview history |
| GET | `/api/analytics/admin/all-interviews` | Retrieve transcripts for admin review |
| DELETE | `/api/analytics/admin/interview/<id>` | Delete interview and its chat records |

## Prompt location

The prompts are defined in Python source code, not stored in a separate prompt database:

- `backend/app/services/interviewer_agent.py` — role, experience, interview-type, adaptive follow-up and output-format instructions.
- `backend/app/services/evaluator_agent.py` — transcript evaluation criteria, scoring rules and JSON output schema.

## Testing

See [Test Cases](docs/TEST_CASES.md). The test document distinguishes manually observed UI evidence from tests that still require execution in a configured local environment. Ollama-dependent end-to-end tests require `ollama serve` and the configured model to be available.

## Important security and deployment notes

This project is currently a development/MVP implementation. Before production deployment:

1. Replace the demo login flow with persistent user accounts and server-validated sessions/JWT. The current login route does not create a secure authenticated session.
2. Remove the hard-coded administrator key from `backend/app/routes/auth.py`; load a strong secret from environment configuration and hash/rotate it.
3. Enforce authorization on admin analytics and deletion endpoints. Hiding admin UI is not access control.
4. Restrict candidate history queries to the authenticated user; do not trust a client-supplied username as authorization.
5. Add request-size limits, rate limiting, CSRF/CORS policy, input validation, secure secret management, and production WSGI hosting.
6. Do not commit `.env`, virtual environments, `node_modules`, generated databases, or personal interview transcripts.

## Current verification status

- Source structure and prompt locations reviewed from the supplied project archive.
- Automated backend/frontend test suites are not included in the supplied project.
- Live Ollama inference and browser end-to-end behavior must be verified on the target Windows machine with Ollama running.
