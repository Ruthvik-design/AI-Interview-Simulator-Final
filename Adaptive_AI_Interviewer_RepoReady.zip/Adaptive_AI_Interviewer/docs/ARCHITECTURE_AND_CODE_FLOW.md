# System Architecture and Code Flow

## 1. Project overview

Adaptive AI Interviewer is a React frontend with a Flask REST backend. The backend uses two prompt-driven agents through the Ollama local HTTP API: an interviewer agent that generates the next question and an evaluator agent that scores the completed transcript. SQLite stores interview sessions, messages, and evaluation data.

## 2. High-level architecture

```mermaid
flowchart LR
    subgraph Browser[Browser]
      P[Login / Setup / Interview / Dashboard / Admin UI]
      AX[frontend/src/services/api.js]
      P --> AX
    end
    AX -->|HTTP JSON| R[Flask routes]
    subgraph Flask[Flask backend]
      R --> IR[interview.py]
      R --> AR[analytics.py]
      R --> LR[auth.py]
      IR --> Q[InterviewerAgent]
      IR --> E[EvaluatorAgent]
      IR --> A[AnalyticsAgent]
      LR --> ORM[SQLAlchemy models]
      IR --> ORM
      AR --> ORM
    end
    Q -->|/api/generate| O[Ollama + llama3.2:3b]
    E -->|/api/generate| O
    ORM --> DB[(SQLite database)]
```

## 3. Frontend flow

1. `frontend/src/main.jsx` mounts the React application.
2. `frontend/src/App.jsx` manages the main application view and navigation state.
3. `pages/Login.jsx` collects a username and candidate/admin selection and calls `loginUser`.
4. `pages/Setup.jsx` collects role, experience, interview type and time limit.
5. `pages/Interview.jsx` starts the session, displays interviewer/candidate messages, submits answers, handles the timer and calls interview completion.
6. `pages/Dashboard.jsx` displays the current evaluation and prior interview history.
7. `pages/AdminPortal.jsx` displays interview records and transcripts and exposes deletion controls.
8. `services/api.js` centralizes Axios calls to the Flask API.

## 4. Backend flow

### Application startup

- `backend/run.py` creates and runs the Flask app.
- `backend/app/__init__.py` loads configuration, enables CORS, initializes SQLAlchemy, creates tables and registers the three blueprints.
- `backend/app/config.py` reads environment variables, including Ollama URL/model and database URI.

### Authentication route

`backend/app/routes/auth.py` accepts a login request and returns the submitted username and role after basic validation. In the supplied version, this is a lightweight demo gate, not a complete secure authentication implementation. It must not be represented as production-grade authentication.

### Starting an interview

1. The frontend calls `POST /api/interview/start` with candidate name, role, experience, interview type and time limit.
2. `routes/interview.py` validates/defaults the configuration and creates an `InterviewSession` row.
3. It calls `InterviewerAgent.generate_next_question(...)` with an empty history.
4. For a new session, the agent returns its opening question. For later turns, it builds a prompt from the selected role, experience, interview type, approved topics and conversation history.
5. The first AI question is saved as a `ChatHistory` row and returned to the browser.

### Submitting an answer and adaptive follow-up

1. The frontend calls `POST /api/interview/respond` with `session_id` and `answer`.
2. The route checks required values, verifies that the session exists and is not already completed, then saves the candidate answer.
3. It loads the ordered conversation history and calls the interviewer agent.
4. The agent sends a prompt to Ollama at `{OLLAMA_BASE_URL}/api/generate`, using `OLLAMA_MODEL` (default `llama3.2:3b`).
5. The prompt instructs the model to keep questions relevant to the selected role, adapt to the candidate's latest answer and experience level, avoid repetition, and ask one question at a time.
6. The response is cleaned and validated. If Ollama is unavailable or the output is invalid/duplicated, the agent uses a deterministic role-aware fallback question.
7. The generated question is saved to `ChatHistory` and returned to the frontend.

### Completing and evaluating an interview

1. The frontend calls `POST /api/interview/complete` with the session ID, either when the candidate selects Finish or the timer expires.
2. The route checks that the session exists and returns a previously saved evaluation if it has already been completed.
3. It loads the transcript and calls `EvaluatorAgent.evaluate_interview(transcript, role, experience)`.
4. The evaluator sends a separate prompt to Ollama. It requests a JSON result with five 0–10 dimensions: Relevance, Completeness, Clarity, Technical Understanding and Communication.
5. The evaluator parses the JSON, validates the required dimensions and bounds, computes the average score, and validates the summary, strengths and improvement lists.
6. The route saves scores and feedback in the `InterviewSession` record.
7. `AnalyticsAgent.compare_with_history` compares the current scores with previous attempts and returns progress text.
8. The frontend displays the evaluation and the dashboard can retrieve it later.

## 5. Prompt storage and configuration

Prompts are Python multiline strings embedded in the agent classes. They are not currently stored in SQLite or a separate prompt file.

| Prompt | Source file | Main responsibility |
|---|---|---|
| Adaptive interviewer prompt | `backend/app/services/interviewer_agent.py` | Generates role-aware next question from interview settings and dialogue |
| Evaluation prompt | `backend/app/services/evaluator_agent.py` | Evaluates transcript and requests structured JSON feedback |

Ollama connection settings are read by `backend/app/config.py` from `.env` or process environment variables. The configured default model is `llama3.2:3b`.

## 6. Database design

### `User`
Stores username, email, password hash, role and creation timestamp. The current login route does not yet use this model for authentication.

### `InterviewSession`
Stores candidate name, role, experience, interview type, time limit, creation time, overall score, score JSON, feedback summary and improvement/strength JSON.

### `ChatHistory`
Stores each interviewer or candidate message, its session foreign key, sender and timestamp.

Relationship: one interview session has many chat-history records.

## 7. API responsibilities

| Route | Responsibility |
|---|---|
| `POST /api/auth/login` | Demo candidate/admin login gate |
| `POST /api/interview/start` | Create session and opening question |
| `POST /api/interview/respond` | Persist candidate answer and next AI question |
| `POST /api/interview/complete` | Evaluate and persist completed interview |
| `GET /api/analytics/history` | Return session summaries for dashboard |
| `GET /api/analytics/admin/all-interviews` | Return all sessions with ordered transcripts |
| `DELETE /api/analytics/admin/interview/<id>` | Delete session and associated messages |

## 8. Error and fallback behavior

- Interviewer generation catches Ollama/network/output failures and attempts a role-specific fallback question.
- Evaluator failures are raised to the route rather than replaced with fabricated/random evaluation scores. The UI should show a retryable error when evaluation fails.
- Backend route validation returns HTTP 400 for missing/invalid request fields and HTTP 404 for unknown sessions.
- Ollama must be running at the configured URL and the exact configured model tag must exist locally.

## 9. Important implementation limitations

- The timer is controlled by the browser; server-side enforcement of elapsed time is not demonstrated in the supplied code.
- Admin and candidate authorization is incomplete; admin endpoints must be protected server-side before deployment.
- The user table exists but is not integrated into the current login route.
- SQLite is suitable for local development and demonstration, not necessarily concurrent production workloads.
- Model responses may vary; output validation reduces malformed evaluations but does not guarantee factual correctness.
