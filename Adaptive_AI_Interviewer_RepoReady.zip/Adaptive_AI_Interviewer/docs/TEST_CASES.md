# Test Plan and Test Cases

## Test environment

- Frontend: React + Vite in a desktop browser.
- Backend: Flask development server (`python run.py`).
- Database: SQLite.
- AI service: Ollama listening at `http://127.0.0.1:11434`.
- Model: `llama3.2:3b` (must be present in `ollama list`).

## Test execution status

The uploaded source archive does not contain an automated test suite or test execution report. The scenarios below are a manual test plan. The screenshots are supporting UI evidence from the supplied conversation; they are not proof that every test passed. Mark actual results and status only after running each scenario on the target machine.

| ID | Module | Test scenario / input | Expected result | Actual result / status |
|---|---|---|---|---|
| TC-01 | Login | Submit candidate login with a non-empty username | Candidate enters setup screen | Not re-executed; verify locally |
| TC-02 | Login | Submit blank username | API rejects request with HTTP 400 | Not re-executed |
| TC-03 | Admin login | Submit invalid admin key | API rejects request with HTTP 401 | Not re-executed |
| TC-04 | Setup | Select Frontend Engineer, Fresher, Technical + HR and a time limit | Configuration is submitted and a session is created | UI screenshot available; re-run to confirm current build |
| TC-05 | Interview start | Start with valid configuration while Ollama/model are available | Session ID and opening question are returned; AI message is saved | Not re-executed |
| TC-06 | Adaptive follow-up | Answer with a project description mentioning React and API integration | Next question should explore the stated project/technology and remain role relevant | Conversation screenshot available; verify current model output |
| TC-07 | Short answer | Answer “I don't remember” | Interviewer asks a simpler clarifying or foundational follow-up | Screenshot available; re-run to confirm |
| TC-08 | Duplicate prevention | Continue several turns with similar answers | Previously asked question is not repeated exactly | Not re-executed |
| TC-09 | Ollama unavailable | Stop Ollama and submit a candidate answer | Interviewer logs connection failure and returns a controlled fallback question | Prior terminal log showed fallback behavior; re-run on current source |
| TC-10 | Empty answer | Submit whitespace as answer | API returns HTTP 400 and does not store an empty answer | Not re-executed |
| TC-11 | Invalid session | Submit a response with an unknown session ID | API returns HTTP 404 | Not re-executed |
| TC-12 | Evaluation | Finish an interview with a non-empty transcript while Ollama is running | Valid JSON evaluation is returned with five bounded scores, strengths and improvements | Not re-executed |
| TC-13 | Evaluation failure | Stop Ollama before completion | Evaluation fails visibly; no fabricated score is saved | Earlier log showed Ollama connection failure and HTTP 503; re-run after current changes |
| TC-14 | Timer | Allow configured interview timer to expire | UI initiates automatic completion/evaluation | Timeout screenshot available; re-run to confirm |
| TC-15 | Dashboard | Open history after completing an interview | Completed interview and evaluation appear | History screenshot available; re-run to confirm |
| TC-16 | Admin review | Open admin portal and select an interview | Transcript and session details are displayed | Not re-executed |
| TC-17 | Delete record | Delete an interview record | Session and its chat messages are deleted and list refreshes | Earlier server log showed DELETE returned HTTP 200; re-run to confirm |
| TC-18 | Ollama model mismatch | Configure a model tag not present in `ollama list` | Clear connection/model error is logged and user receives controlled error/fallback | Not re-executed |

## Screenshots supplied as UI evidence

### Interview setup
![Interview setup](screenshots/01-setup-screen.png)

### Interview conversation
![Interview conversation](screenshots/02-interview-chat.png)

### Adaptive follow-up question
![Adaptive follow-up](screenshots/03-adaptive-followup.png)

### Interview history and evaluation view
![Interview history](screenshots/04-interview-history.png)

### Timer expiry and evaluation state
![Timeout evaluation](screenshots/05-timeout-evaluation.png)

### Additional conversation state
![Interview conversation detail](screenshots/06-interview-conversation.png)

## How to execute the tests manually

1. Start Ollama with `ollama serve` and verify `ollama list` includes `llama3.2:3b`.
2. Start the Flask backend and Vite frontend using the README instructions.
3. Run the scenarios in order and capture the browser plus backend terminal output for each important result.
4. For API validation, use the browser network panel or Postman and record HTTP status and response body.
5. Update the Actual Result / Status column with `PASS`, `FAIL`, or `BLOCKED`, including a short observation.
6. Do not mark Ollama-dependent scenarios as passed if the model was not running.

## Checks performed during documentation preparation

| Check | Result | Notes |
|---|---|---|
| Python syntax compilation | PASS | `python -m compileall -q backend/app backend/run.py` completed successfully against the supplied updated source. |
| Frontend production build | BLOCKED | The archived `node_modules` tree contains Windows-specific optional Rollup binaries; this Linux build environment could not load `@rollup/rollup-linux-x64-gnu`. Re-run `npm ci` and `npm run build` on the target development machine. |
| Live Ollama generation | NOT RUN | Ollama is not available in this execution environment. Verify locally with `ollama serve` and `ollama list`. |
| Browser end-to-end tests | NOT RUN | Requires the local frontend, Flask server, browser and Ollama model. |
