
import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 120000,
  headers: {
    'Content-Type': 'application/json'
  }
});

export const loginUser = async (username, role, password = '') => {
  const response = await api.post('/auth/login', {
    username,
    role,
    password
  });
  return response.data;
};

export const startInterview = async (setupData) => {
  const response = await api.post('/interview/start', setupData);
  return response.data;
};

export const sendAnswer = async (session_id, answer) => {
  const response = await api.post('/interview/respond', {
    session_id,
    answer
  });
  return response.data;
};

export const completeInterview = async (session_id) => {
  const response = await api.post('/interview/complete', {
    session_id
  });
  return response.data;
};

export const getAdminAllInterviews = async () => {
  const response = await api.get('/analytics/admin/all-interviews');
  return response.data;
};

export const deleteAdminInterview = async (session_id) => {
  const response = await api.delete(
    `/analytics/admin/interview/${session_id}`
  );
  return response.data;
};

export const deleteInterview = deleteAdminInterview;

export const getInterviewHistory = async (username) => {
  const response = await api.get('/analytics/history', {
    params: { username }
  });
  return response.data;
};

export const getAdminOverview = async () => {
  const response = await api.get('/analytics/admin/overview');
  return response.data;
};

export const getAdminAgentFeedback = async () => {
  const response = await api.get('/analytics/admin/agent-feedback');
  return response.data;
};

export const submitAgentFeedback = async (feedbackData) => {
  const response = await api.post(
    '/analytics/feedback',
    feedbackData
  );
  return response.data;
};
