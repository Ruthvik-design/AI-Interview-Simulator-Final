import React from 'react';
import { Bot, LayoutDashboard, PlayCircle, Shield, LogOut, User } from 'lucide-react';

export default function Navbar({ activeTab, setActiveTab, currentUser, onLogout }) {
  return (
    <nav className="bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center shadow-sm">
      <div className="flex items-center space-x-3">
        <div className="p-2 bg-blue-600 rounded-lg text-white">
          <Bot className="w-6 h-6" />
        </div>
        <div>
          <h1 className="font-bold text-xl text-gray-800">Adaptive AI Interviewer</h1>
          <p className="text-xs text-gray-500">BITS Pilani Design Project • Ollama Engine</p>
        </div>
      </div>
      
      <div className="flex items-center space-x-3">
        {currentUser && (
          <div className="flex items-center space-x-2 bg-gray-100 px-3 py-1.5 rounded-lg text-xs font-semibold text-gray-700 mr-2">
            <User className="w-4 h-4 text-blue-600" />
            <span>{currentUser.username}</span>
            <span className={`ml-1 px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
              currentUser.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
            }`}>
              {currentUser.role}
            </span>
          </div>
        )}

        <button
          onClick={() => setActiveTab('setup')}
          className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
            activeTab === 'setup' || activeTab === 'interview'
              ? 'bg-blue-50 text-blue-600'
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          <PlayCircle className="w-4 h-4" />
          <span>New Session</span>
        </button>

        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
            activeTab === 'dashboard'
              ? 'bg-blue-50 text-blue-600'
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>My History</span>
        </button>

        {currentUser?.role === 'admin' && (
          <button
            onClick={() => setActiveTab('admin')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
              activeTab === 'admin'
                ? 'bg-purple-50 text-purple-600'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>Admin Portal</span>
          </button>
        )}

        {currentUser && (
          <button
            onClick={onLogout}
            title="Logout"
            className="p-2 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        )}
      </div>
    </nav>
  );
}
