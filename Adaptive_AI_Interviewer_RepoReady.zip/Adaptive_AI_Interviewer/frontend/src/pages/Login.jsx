import React, { useState } from 'react';
import { loginUser } from '../services/api';
import { Shield, User, Lock, ArrowRight } from 'lucide-react';

export default function Login({ onLoginSuccess }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('user'); // 'user' or 'admin'
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const data = await loginUser(username, role, password);
      onLoginSuccess(data);
    } catch (err) {
      const serverError = err.response?.data?.error || err.message || "Login failed.";
      setError(serverError);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="max-w-md w-full bg-white rounded-xl shadow-sm border border-gray-200 p-8 space-y-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800">Welcome to Adaptive AI</h2>
          <p className="text-xs text-gray-500 mt-1">Sign in as Candidate or Admin Evaluator</p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-600 text-xs p-3 rounded-lg font-medium">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">
              Username / Name
            </label>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="e.g. John Doe"
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase mb-2">
              Account Role
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => { setRole('user'); setPassword(''); setError(''); }}
                className={`py-2.5 px-4 rounded-lg text-sm font-semibold border flex items-center justify-center space-x-2 transition-all ${
                  role === 'user'
                    ? 'border-blue-500 text-blue-600 bg-blue-50/50 shadow-sm'
                    : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                }`}
              >
                <User className="w-4 h-4" />
                <span>Candidate</span>
              </button>

              <button
                type="button"
                onClick={() => { setRole('admin'); setError(''); }}
                className={`py-2.5 px-4 rounded-lg text-sm font-semibold border flex items-center justify-center space-x-2 transition-all ${
                  role === 'admin'
                    ? 'border-purple-600 text-purple-600 bg-purple-50/50 shadow-sm'
                    : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                }`}
              >
                <Shield className="w-4 h-4" />
                <span>Admin Access</span>
              </button>
            </div>
          </div>

          {role === 'admin' && (
            <div className="pt-1">
              <label className="flex items-center space-x-1 text-xs font-semibold text-purple-700 uppercase mb-1">
                <Lock className="w-3.5 h-3.5" />
                <span>Admin Security Key</span>
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter security key"
                className="w-full px-4 py-2.5 border border-purple-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 bg-purple-50/20"
              />
            </div>
          )}

          <button
            type="submit"
            className={`w-full py-3 rounded-lg text-sm font-bold text-white transition-colors flex items-center justify-center space-x-2 ${
              role === 'admin' ? 'bg-purple-600 hover:bg-purple-700' : 'bg-blue-600 hover:bg-blue-700'
            }`}
          >
            <ArrowRight className="w-4 h-4" />
            <span>Continue to Platform</span>
          </button>
        </form>
      </div>
    </div>
  );
}