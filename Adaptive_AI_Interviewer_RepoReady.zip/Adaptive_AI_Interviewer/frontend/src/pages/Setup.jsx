
import React, { useState } from 'react';
import {
  Sparkles,
  Briefcase,
  Award,
  MessageSquare,
  Clock
} from 'lucide-react';

const PRESET_ROLES = [
  'Software Developer',
  'Frontend Engineer',
  'Backend Developer',
  'Full Stack Developer',
  'Data Scientist',
  'Data Engineer',
  'Machine Learning Engineer',
  'Product Manager',
  'DevOps Engineer',
  'Cloud Architect',
  'Cybersecurity Specialist',
  'Business Analyst',
  'Custom / Other'
];

export default function Setup({
  onStart,
  loading = false,
  currentUser
}) {

  const [formData, setFormData] = useState({
    role: 'Software Developer',
    customRole: '',
    experience: 'Fresher (0-1 Yrs)',
    interview_type: 'Technical + HR',
    time_limit_minutes: 10
  });

  const handleSubmit = (e) => {
    e.preventDefault();

    const finalRole =
      formData.role === 'Custom / Other'
        ? formData.customRole.trim()
        : formData.role;

    if (!finalRole) {
      alert('Please enter your target role.');
      return;
    }

    if (typeof onStart !== 'function') {
      alert('Interview start function is not connected.');
      return;
    }

    const interviewConfig = {
      role: finalRole,
      experience: formData.experience,
      interview_type: formData.interview_type,
      time_limit_minutes: Number(
        formData.time_limit_minutes
      ),
      user_name: currentUser?.username || 'Candidate User'
    };

    console.log(
      'Submitting interview configuration:',
      interviewConfig
    );

    onStart(interviewConfig);
  };

  return (
    <div className="max-w-2xl mx-auto my-12 bg-white rounded-xl shadow-sm border border-gray-200 p-8">

      {/* TITLE */}
      <div className="text-center mb-8">

        <h2 className="text-2xl font-bold text-gray-800">
          Configure Your AI Mock Interview
        </h2>

        <p className="text-gray-500 text-sm mt-1">
          Select your target role, timed setup, and interview mode
          (Powered by Ollama).
        </p>

      </div>

      <form
        onSubmit={handleSubmit}
        className="space-y-6"
      >

        {/* TARGET ROLE */}
        <div>

          <label className="flex items-center font-medium text-gray-700 text-sm mb-2">

            <Briefcase className="w-4 h-4 mr-2 text-blue-600" />

            Target Role

          </label>

          <select
            value={formData.role}
            onChange={(e) =>
              setFormData({
                ...formData,
                role: e.target.value
              })
            }
            disabled={loading}
            className="w-full border border-gray-300 rounded-lg p-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          >

            {PRESET_ROLES.map((role) => (
              <option key={role} value={role}>
                {role}
              </option>
            ))}

          </select>

          {formData.role === 'Custom / Other' && (

            <input
              type="text"
              required
              placeholder="Enter your specific target role..."
              value={formData.customRole}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  customRole: e.target.value
                })
              }
              disabled={loading}
              className="mt-3 w-full border border-gray-300 rounded-lg p-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-sm"
            />

          )}

        </div>

        {/* TIME LIMIT */}
        <div>

          <label className="flex items-center font-medium text-gray-700 text-sm mb-2">

            <Clock className="w-4 h-4 mr-2 text-blue-600" />

            Interview Time Limit

          </label>

          <select
            value={formData.time_limit_minutes}
            onChange={(e) =>
              setFormData({
                ...formData,
                time_limit_minutes: Number(e.target.value)
              })
            }
            disabled={loading}
            className="w-full border border-gray-300 rounded-lg p-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          >

            <option value={5}>
              5 Minutes (Quick Drill)
            </option>

            <option value={10}>
              10 Minutes (Standard)
            </option>

            <option value={15}>
              15 Minutes (Comprehensive)
            </option>

          </select>

        </div>

        {/* EXPERIENCE */}
        <div>

          <label className="flex items-center font-medium text-gray-700 text-sm mb-2">

            <Award className="w-4 h-4 mr-2 text-blue-600" />

            Experience Level

          </label>

          <select
            value={formData.experience}
            onChange={(e) =>
              setFormData({
                ...formData,
                experience: e.target.value
              })
            }
            disabled={loading}
            className="w-full border border-gray-300 rounded-lg p-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          >

            <option value="Fresher (0-1 Yrs)">
              Fresher (0-1 Yrs)
            </option>

            <option value="Mid-Level (2-4 Yrs)">
              Mid-Level (2-4 Yrs)
            </option>

            <option value="Senior (5+ Yrs)">
              Senior (5+ Yrs)
            </option>

          </select>

        </div>

        {/* INTERVIEW TYPE */}
        <div>

          <label className="flex items-center font-medium text-gray-700 text-sm mb-2">

            <MessageSquare className="w-4 h-4 mr-2 text-blue-600" />

            Interview Type

          </label>

          <select
            value={formData.interview_type}
            onChange={(e) =>
              setFormData({
                ...formData,
                interview_type: e.target.value
              })
            }
            disabled={loading}
            className="w-full border border-gray-300 rounded-lg p-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          >

            <option value="Technical + HR">
              Technical + HR
            </option>

            <option value="Technical Interview">
              Technical Interview
            </option>

            <option value="HR / Behavioral">
              HR / Behavioral
            </option>

            <option value="Role-specific Deep Dive">
              Role-specific Deep Dive
            </option>

          </select>

        </div>

        {/* START BUTTON */}
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-blue-600 text-white font-medium py-3 rounded-lg flex items-center justify-center space-x-2 hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >

          <Sparkles className="w-5 h-5" />

          <span>
            {loading
              ? 'Initializing Ollama Agent...'
              : 'Begin Timed Interview'}
          </span>

        </button>

      </form>

    </div>
  );
}
