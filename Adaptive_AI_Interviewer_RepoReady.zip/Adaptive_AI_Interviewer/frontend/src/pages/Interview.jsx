
import React, {
  useState,
  useRef,
  useEffect
} from 'react';

import {
  Send,
  Clock,
  AlertTriangle,
  User,
  Bot
} from 'lucide-react';

export default function Interview({ session }) {

  const [messages, setMessages] = useState([
    {
      sender: 'ai',
      text: session.initialQuestion
    }
  ]);

  const [inputAnswer, setInputAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const [timeLeft, setTimeLeft] = useState(
    session.time_limit_minutes * 60
  );

  const [autoSubmitting, setAutoSubmitting] = useState(false);
  const [error, setError] = useState('');

  const chatEndRef = useRef(null);
  const finishStarted = useRef(false);

  // SCROLL TO LATEST MESSAGE
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({
      behavior: 'smooth'
    });
  }, [messages, loading]);

  // INTERVIEW TIMER
  useEffect(() => {

    if (timeLeft <= 0) {
      finishInterview();
      return;
    }

    const timer = window.setTimeout(() => {
      setTimeLeft(previous =>
        Math.max(0, previous - 1)
      );
    }, 1000);

    return () => window.clearTimeout(timer);

  }, [timeLeft]);

  // FORMAT TIMER
  const formatTime = (seconds) => {

    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;

    return (
      String(minutes).padStart(2, '0') +
      ':' +
      String(remainingSeconds).padStart(2, '0')
    );
  };

  // FINISH INTERVIEW
  const finishInterview = async () => {

    if (finishStarted.current) return;

    finishStarted.current = true;

    setAutoSubmitting(true);
    setError('');

    try {

      await session.onFinish();

    } catch (err) {

      console.error('Interview completion failed:', err);

      setError(
        err.response?.data?.error ||
        err.message ||
        'Could not evaluate interview. Please try again.'
      );

      finishStarted.current = false;
      setAutoSubmitting(false);
    }
  };

  // SEND ANSWER
  const handleSend = async (event) => {

    event.preventDefault();

    const answer = inputAnswer.trim();

    if (
      !answer ||
      loading ||
      autoSubmitting ||
      finishStarted.current
    ) {
      return;
    }

    setInputAnswer('');

    setMessages(previous => [
      ...previous,
      {
        sender: 'user',
        text: answer
      }
    ]);

    setLoading(true);
    setError('');

    try {

      const nextQuestion = await session.onSendAnswer(answer);

      setMessages(previous => [
        ...previous,
        {
          sender: 'ai',
          text: nextQuestion
        }
      ]);

    } catch (err) {

      console.error('Answer submission failed:', err);

      setError(
        err.response?.data?.error ||
        err.message ||
        'Could not send your answer. Please try again.'
      );

      setMessages(previous =>
        previous.filter(
          (message, index) =>
            !(
              index === previous.length - 1 &&
              message.sender === 'user' &&
              message.text === answer
            )
        )
      );

      setInputAnswer(answer);

    } finally {

      setLoading(false);

    }
  };

  return (

    <div className="max-w-4xl mx-auto my-8 bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col h-[75vh]">

      {/* INTERVIEW HEADER */}
      <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between items-center rounded-t-xl">

        <div>

          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2 py-1 rounded">

            {session.interview_type}

          </span>

          <h3 className="font-semibold text-gray-800 text-sm mt-1">

            {session.role} ({session.experience})

          </h3>

        </div>

        {/* TIMER */}
        <div
          className={`flex items-center space-x-2 font-mono font-bold text-sm px-3 py-1.5 rounded-lg ${
            timeLeft < 120
              ? 'bg-red-100 text-red-700 animate-pulse'
              : 'bg-gray-200 text-gray-700'
          }`}
        >

          <Clock className="w-4 h-4" />

          <span>{formatTime(timeLeft)}</span>

        </div>

      </div>

      {/* CHAT AREA */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">

        {messages.map((message, index) => (

          <div
            key={index}
            className={`flex items-start space-x-3 ${
              message.sender === 'user'
                ? 'justify-end'
                : ''
            }`}
          >

            {message.sender === 'ai' && (

              <div className="p-2 bg-blue-100 rounded-full text-blue-600">

                <Bot className="w-5 h-5" />

              </div>

            )}

            <div
              className={`p-4 rounded-xl max-w-xl text-sm leading-relaxed ${
                message.sender === 'user'
                  ? 'bg-blue-600 text-white rounded-tr-none'
                  : 'bg-gray-100 text-gray-800 rounded-tl-none'
              }`}
            >

              {message.text}

            </div>

            {message.sender === 'user' && (

              <div className="p-2 bg-gray-200 rounded-full text-gray-600">

                <User className="w-5 h-5" />

              </div>

            )}

          </div>

        ))}

        {/* AI LOADING */}
        {loading && (

          <div className="flex items-center space-x-2 text-gray-400 text-sm italic">

            <Bot className="w-5 h-5 animate-pulse" />

            <span>
              Ollama AI model generating response...
            </span>

          </div>

        )}

        {/* TIMER EXPIRED */}
        {autoSubmitting && (

          <div className="bg-amber-50 border border-amber-200 p-3 rounded-lg flex items-center space-x-2 text-amber-800 text-sm">

            <AlertTriangle className="w-5 h-5" />

            <span>
              Time expired! Evaluating your interview...
            </span>

          </div>

        )}

        {/* ERROR */}
        {error && (

          <div
            role="alert"
            className="text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg p-3"
          >

            {error}

          </div>

        )}

        <div ref={chatEndRef} />

      </div>

      {/* ANSWER INPUT */}
      <form
        onSubmit={handleSend}
        className="p-4 border-t border-gray-200 flex space-x-3 bg-white rounded-b-xl"
      >

        <input
          type="text"
          placeholder={
            autoSubmitting
              ? 'Interview is being evaluated...'
              : 'Type your response here...'
          }
          value={inputAnswer}
          onChange={(event) =>
            setInputAnswer(event.target.value)
          }
          disabled={loading || autoSubmitting}
          className="flex-1 border border-gray-300 rounded-lg px-4 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />

        {/* SEND BUTTON */}
        <button
          type="submit"
          disabled={
            loading ||
            autoSubmitting ||
            !inputAnswer.trim()
          }
          className="bg-blue-600 text-white px-5 py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
        >

          <Send className="w-4 h-4" />

        </button>

        {/* FINISH BUTTON */}
        <button
          type="button"
          onClick={finishInterview}
          disabled={autoSubmitting || loading}
          className="border border-gray-300 text-gray-700 px-4 py-3 rounded-lg text-sm hover:bg-gray-50 disabled:opacity-50"
        >

          Finish

        </button>

      </form>

    </div>
  );
}
