import React, { useEffect, useState } from 'react';

import {
  getInterviewHistory,
  deleteInterview,
  submitAgentFeedback
} from '../services/api';

import {
  Calendar,
  AlertCircle,
  CheckCircle,
  Star,
  Trash2,
  MessageSquare,
  Send,
  Bot,
  ThumbsUp
} from 'lucide-react';

export default function Dashboard({ currentResult, currentUser }) {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  const [rating, setRating] = useState(0);
  const [relevance, setRelevance] = useState('Mostly relevant');
  const [accuracy, setAccuracy] = useState('Mostly accurate');
  const [comments, setComments] = useState('');
  const [recommend, setRecommend] = useState('yes');

  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [feedbackError, setFeedbackError] = useState('');

  const username = typeof currentUser === 'object'
    ? currentUser?.username
    : currentUser;

  // Reset feedback form whenever a new interview result arrives.
  useEffect(() => {
    setRating(0);
    setRelevance('Mostly relevant');
    setAccuracy('Mostly accurate');
    setComments('');
    setRecommend('yes');
    setSubmitted(false);
    setFeedbackError('');
  }, [currentResult?.session_id]);

  // Load candidate interview history.
  useEffect(() => {
    let isActive = true;

    const fetchData = async () => {
      if (!username) {
        setHistory([]);
        setLoading(false);
        return;
      }

      setLoading(true);

      try {
        const data = await getInterviewHistory(username);

        if (isActive) {
          setHistory(Array.isArray(data) ? data : []);
        }
      } catch (error) {
        console.error('Failed to load interview history:', error);

        if (isActive) {
          setHistory([]);
        }
      } finally {
        if (isActive) {
          setLoading(false);
        }
      }
    };

    fetchData();

    return () => {
      isActive = false;
    };
  }, [username, currentResult?.session_id]);

  const handleDelete = async (id) => {
    const confirmed = window.confirm(
      'Are you sure you want to delete this interview record?'
    );

    if (!confirmed) return;

    try {
      await deleteInterview(id);

      setHistory(previous =>
        previous.filter(item => item.id !== id)
      );
    } catch (error) {
      console.error('Failed to delete interview:', error);
      alert(
        error.response?.data?.error ||
        'Could not delete this interview.'
      );
    }
  };

  const handleFeedbackSubmit = async (event) => {
    event.preventDefault();

    if (!currentResult?.session_id) {
      setFeedbackError(
        'Interview session ID is missing. Please refresh and check your interview result.'
      );
      return;
    }

    if (!rating) {
      setFeedbackError('Please select a star rating.');
      return;
    }

    if (!username) {
      setFeedbackError('Candidate username is missing. Please log in again.');
      return;
    }

    setSubmitting(true);
    setFeedbackError('');

    try {
      await submitAgentFeedback({
        session_id: currentResult.session_id,
        username,
        rating,
        question_relevance: relevance,
        agent_accuracy: accuracy,
        feedback_text: comments,
        would_recommend: recommend === 'yes'
      });

      setSubmitted(true);

      // Update the history immediately without waiting for another request.
      setHistory(previous =>
        previous.map(item =>
          item.id === currentResult.session_id
            ? {
                ...item,
                agent_feedback: {
                  rating,
                  question_relevance: relevance,
                  agent_accuracy: accuracy,
                  feedback_text: comments,
                  would_recommend: recommend === 'yes'
                }
              }
            : item
        )
      );
    } catch (error) {
      console.error('Feedback submission failed:', error);

      setFeedbackError(
        error.response?.data?.error ||
        'Unable to submit feedback. Please try again.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  const evaluation = currentResult?.evaluation;

  return (
    <div className="max-w-5xl mx-auto my-8 space-y-8">

      {/* LATEST INTERVIEW EVALUATION */}
      {evaluation && (
        <div className="bg-white border border-blue-200 rounded-xl p-6 shadow-sm space-y-6">

          <div className="flex flex-wrap justify-between items-center gap-3">
            <div className="flex items-center space-x-2 text-blue-600 font-semibold text-sm">
              <Star className="w-5 h-5 fill-current" />
              <span>Latest Interview Evaluation</span>
            </div>

            <span className="text-xs font-bold bg-blue-100 text-blue-700 px-3 py-1 rounded-full">
              Overall: {evaluation.overall_score ?? 0} / 10
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {Object.entries(evaluation.parameters || {}).map(
              ([param, score]) => (
                <div
                  key={param}
                  className="bg-white p-3 rounded-lg border border-gray-200 text-center"
                >
                  <div className="text-xs text-gray-500 font-medium">
                    {param}
                  </div>

                  <div className="text-lg font-bold text-gray-800 mt-1">
                    {score} / 10
                  </div>
                </div>
              )
            )}
          </div>

          <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
            <span className="text-blue-700 text-xs font-semibold uppercase">
              AI Feedback Summary
            </span>

            <p className="text-sm text-gray-700 mt-2 leading-relaxed">
              {evaluation.feedback_summary || 'No feedback summary available.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

            <div className="bg-amber-50 border border-amber-200 p-4 rounded-lg">
              <h4 className="flex items-center text-sm font-bold text-amber-900 mb-2">
                <AlertCircle className="w-4 h-4 mr-2" />
                Areas for Improvement
              </h4>

              <ul className="list-disc list-inside text-xs text-amber-900 space-y-1">
                {(evaluation.areas_for_improvement || []).map(
                  (item, index) => (
                    <li key={index}>{item}</li>
                  )
                )}
              </ul>
            </div>

            <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-lg">
              <h4 className="flex items-center text-sm font-bold text-emerald-900 mb-2">
                <CheckCircle className="w-4 h-4 mr-2" />
                Key Strengths
              </h4>

              <ul className="list-disc list-inside text-xs text-emerald-900 space-y-1">
                {(evaluation.key_strengths || []).map(
                  (item, index) => (
                    <li key={index}>{item}</li>
                  )
                )}
              </ul>
            </div>

          </div>
        </div>
      )}

      {/* AI AGENT FEEDBACK FORM */}
      {currentResult?.session_id && (
        <div className="bg-white border border-purple-200 rounded-xl p-6 shadow-sm space-y-5">

          <div className="flex items-center space-x-3">
            <div className="bg-purple-100 p-3 rounded-xl">
              <Bot className="w-6 h-6 text-purple-700" />
            </div>

            <div>
              <h3 className="font-bold text-gray-800 text-lg">
                Rate Your AI Interview Experience
              </h3>

              <p className="text-xs text-gray-500 mt-1">
                Your feedback helps us improve our AI interviewer.
              </p>
            </div>
          </div>

          {submitted ? (
            <div className="bg-green-50 border border-green-200 rounded-lg p-5 text-center">
              <CheckCircle className="w-9 h-9 text-green-600 mx-auto mb-2" />

              <h4 className="font-bold text-green-800">
                Thank You for Your Feedback!
              </h4>

              <p className="text-sm text-green-700 mt-1">
                Your feedback has been recorded successfully.
              </p>
            </div>
          ) : (
            <form onSubmit={handleFeedbackSubmit} className="space-y-5">

              {/* STAR RATING */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  1. How would you rate the AI interviewer?
                </label>

                <div className="flex items-center space-x-3">
                  {[1, 2, 3, 4, 5].map(number => (
                    <button
                      key={number}
                      type="button"
                      onClick={() => setRating(number)}
                      className="transition-transform hover:scale-110"
                      aria-label={`Rate ${number} out of 5`}
                    >
                      <Star
                        className={`w-8 h-8 ${
                          number <= rating
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-gray-300'
                        }`}
                      />
                    </button>
                  ))}

                  <span className="text-sm font-semibold text-gray-600">
                    {rating ? `${rating}/5` : 'Select rating'}
                  </span>
                </div>
              </div>

              {/* QUESTION RELEVANCE */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  2. Were the interview questions relevant to your selected role?
                </label>

                <select
                  value={relevance}
                  onChange={event => setRelevance(event.target.value)}
                  className="w-full border border-gray-300 rounded-lg p-3 text-sm bg-white"
                >
                  <option>Very relevant</option>
                  <option>Mostly relevant</option>
                  <option>Not relevant</option>
                </select>
              </div>

              {/* AI ACCURACY */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  3. How accurate and understandable were the AI questions?
                </label>

                <select
                  value={accuracy}
                  onChange={event => setAccuracy(event.target.value)}
                  className="w-full border border-gray-300 rounded-lg p-3 text-sm bg-white"
                >
                  <option>Very accurate</option>
                  <option>Mostly accurate</option>
                  <option>Needs improvement</option>
                </select>
              </div>

              {/* COMMENTS */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  4. What improvements would you suggest?
                </label>

                <textarea
                  value={comments}
                  onChange={event => setComments(event.target.value)}
                  rows={4}
                  maxLength={3000}
                  placeholder="Share your experience, problems or suggestions..."
                  className="w-full border border-gray-300 rounded-lg p-3 text-sm resize-none focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>

              {/* RECOMMENDATION */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  5. Would you recommend this AI interviewer to others?
                </label>

                <div className="flex space-x-6">
                  <label className="flex items-center space-x-2 text-sm">
                    <input
                      type="radio"
                      name="recommend"
                      value="yes"
                      checked={recommend === 'yes'}
                      onChange={event => setRecommend(event.target.value)}
                    />
                    <span>Yes</span>
                  </label>

                  <label className="flex items-center space-x-2 text-sm">
                    <input
                      type="radio"
                      name="recommend"
                      value="no"
                      checked={recommend === 'no'}
                      onChange={event => setRecommend(event.target.value)}
                    />
                    <span>No</span>
                  </label>
                </div>
              </div>

              {feedbackError && (
                <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-lg text-sm">
                  {feedbackError}
                </div>
              )}

              <button
                type="submit"
                disabled={submitting || !rating}
                className="w-full bg-purple-600 text-white py-3 rounded-lg font-semibold flex items-center justify-center space-x-2 hover:bg-purple-700 disabled:opacity-50"
              >
                <Send className="w-4 h-4" />

                <span>
                  {submitting ? 'Submitting...' : 'Submit Feedback'}
                </span>
              </button>
            </form>
          )}
        </div>
      )}

      {/* PAST INTERVIEW HISTORY */}
      <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">

        <h3 className="font-bold text-gray-800 text-lg mb-4 flex items-center space-x-2">
          <Calendar className="w-5 h-5 text-gray-500" />
          <span>Past Interview Attempts</span>
        </h3>

        {loading ? (
          <p className="text-sm text-gray-500 py-4">
            Loading interview history...
          </p>
        ) : history.length === 0 ? (
          <p className="text-sm text-gray-500 py-4">
            No completed interviews recorded yet.
          </p>
        ) : (
          <div className="divide-y divide-gray-200">
            {history.map(item => (
              <div key={item.id} className="py-5 space-y-3">

                <div className="flex justify-between items-start gap-3">
                  <div>
                    <div className="font-semibold text-gray-800 text-sm">
                      {item.role}
                    </div>

                    <div className="text-xs text-gray-500 mt-1">
                      {item.interview_type} • {item.date}
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <span className="text-xs text-gray-400">
                        Score
                      </span>

                      <div className="text-sm font-bold text-blue-600">
                        {item.overall_score ?? 0} / 10
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDelete(item.id)}
                      className="p-2 text-gray-400 hover:text-red-600 rounded-lg"
                      title="Delete attempt"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {item.feedback && (
                  <p className="text-xs text-gray-600 italic bg-gray-50 p-3 rounded border">
                    "{item.feedback}"
                  </p>
                )}

                {item.agent_feedback && (
                  <div className="bg-purple-50 border border-purple-100 rounded-lg p-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-purple-800">
                        Your AI Agent Feedback
                      </span>

                      <span className="text-sm font-bold text-amber-600">
                        {'★'.repeat(item.agent_feedback.rating || 0)}
                        {'☆'.repeat(5 - (item.agent_feedback.rating || 0))}
                      </span>
                    </div>

                    <p className="text-xs text-purple-800 mt-1">
                      Question relevance: {item.agent_feedback.question_relevance}
                    </p>

                    {item.agent_feedback.feedback_text && (
                      <p className="text-xs text-gray-600 mt-2">
                        {item.agent_feedback.feedback_text}
                      </p>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">

                  {item.areas_for_improvement?.length > 0 && (
                    <div className="bg-amber-50 border border-amber-100 p-3 rounded text-xs">
                      <span className="font-bold text-amber-900 block mb-1">
                        Areas for Improvement
                      </span>

                      <ul className="list-disc list-inside text-amber-800 space-y-1">
                        {item.areas_for_improvement.map((value, index) => (
                          <li key={index}>{value}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {item.key_strengths?.length > 0 && (
                    <div className="bg-emerald-50 border border-emerald-100 p-3 rounded text-xs">
                      <span className="font-bold text-emerald-900 block mb-1">
                        Key Strengths
                      </span>

                      <ul className="list-disc list-inside text-emerald-800 space-y-1">
                        {item.key_strengths.map((value, index) => (
                          <li key={index}>{value}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}