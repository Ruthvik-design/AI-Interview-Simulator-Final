import React, { useEffect, useState } from 'react';

import {
  getAdminAllInterviews,
  deleteAdminInterview,
  getAdminOverview,
  getAdminAgentFeedback
} from '../services/api';

import {
  Shield,
  MessageSquare,
  Trash2,
  Users,
  ClipboardList,
  Star,
  TrendingUp,
  TrendingDown,
  Minus,
  Bot,
  ThumbsUp,
  Activity,
  Award
} from 'lucide-react';

export default function AdminPortal() {
  const [interviews, setInterviews] = useState([]);
  const [overview, setOverview] = useState(null);
  const [agentFeedback, setAgentFeedback] = useState(null);

  const [selectedSession, setSelectedSession] = useState(null);
  const [selectedCandidate, setSelectedCandidate] = useState(null);

  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchAdminData();
  }, []);

  const fetchAdminData = async () => {
    setLoading(true);
    setError('');

    try {
      const [interviewData, overviewData, feedbackData] =
        await Promise.all([
          getAdminAllInterviews(),
          getAdminOverview(),
          getAdminAgentFeedback()
        ]);

      const safeInterviews = Array.isArray(interviewData)
        ? interviewData
        : [];

      setInterviews(safeInterviews);
      setOverview(overviewData || {});
      setAgentFeedback(feedbackData || {});

      setSelectedSession(previous =>
        safeInterviews.find(item => item.id === previous?.id) ||
        safeInterviews[0] ||
        null
      );

      const candidates = overviewData?.candidates || [];

      setSelectedCandidate(previous =>
        candidates.find(
          candidate => candidate.username === previous?.username
        ) ||
        candidates[0] ||
        null
      );

    } catch (error) {
      console.error('Admin data loading failed:', error);

      setError(
        error.response?.data?.error ||
        'Unable to load admin analytics. Please check the backend.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    const confirmed = window.confirm(
      'Are you sure you want to delete this interview and its associated feedback?'
    );

    if (!confirmed) return;

    try {
      await deleteAdminInterview(id);

      setInterviews(previous =>
        previous.filter(item => item.id !== id)
      );

      setSelectedSession(previous =>
        previous?.id === id ? null : previous
      );

      await fetchAdminData();

    } catch (error) {
      console.error('Failed to delete interview:', error);

      alert(
        error.response?.data?.error ||
        'Unable to delete interview.'
      );
    }
  };

  const StatCard = ({ title, value, icon: Icon, color }) => (
    <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
      <div className="flex justify-between items-center">
        <div>
          <p className="text-xs text-gray-500 font-semibold">
            {title}
          </p>

          <h3 className={`text-2xl font-extrabold mt-2 ${color}`}>
            {value}
          </h3>
        </div>

        <div className="bg-gray-50 p-3 rounded-xl">
          <Icon className={`w-6 h-6 ${color}`} />
        </div>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto p-8 text-center text-gray-500">
        Loading admin analytics...
      </div>
    );
  }

  if (error && !overview) {
    return (
      <div className="max-w-7xl mx-auto my-8 p-6 bg-red-50 border border-red-200 rounded-xl">
        <p className="text-red-700 text-sm">{error}</p>

        <button
          onClick={fetchAdminData}
          className="mt-4 bg-purple-700 text-white px-4 py-2 rounded-lg text-sm"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto my-8 space-y-6">

      {/* HEADER */}
      <div className="bg-purple-900 text-white p-6 rounded-xl shadow-sm">
        <div className="flex items-center space-x-3">
          <Shield className="w-7 h-7 text-purple-300" />

          <div>
            <h2 className="text-xl font-bold">
              Admin Supervision Portal
            </h2>

            <p className="text-purple-200 text-xs mt-1">
              Overall candidate performance and AI interviewer monitoring.
            </p>
          </div>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-lg text-sm">
          {error}
        </div>
      )}

      {/* NAVIGATION */}
      <div className="bg-white rounded-xl border border-gray-200 p-2 flex flex-wrap gap-2">
        {[
          { id: 'overview', label: 'Overall Overview' },
          { id: 'candidates', label: 'Candidate Analytics' },
          { id: 'feedback', label: 'AI Agent Feedback' },
          { id: 'interviews', label: 'Interview Records' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold ${
              activeTab === tab.id
                ? 'bg-purple-700 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            {tab.label}
          </button>
        ))}

        <button
          onClick={fetchAdminData}
          className="ml-auto px-4 py-2 rounded-lg text-sm font-semibold text-purple-700 hover:bg-purple-50"
        >
          Refresh
        </button>
      </div>

      {/* OVERALL OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6">

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              title="Total Candidates"
              value={overview?.total_candidates ?? 0}
              icon={Users}
              color="text-blue-600"
            />

            <StatCard
              title="Total Interviews"
              value={overview?.total_interviews ?? 0}
              icon={ClipboardList}
              color="text-purple-600"
            />

            <StatCard
              title="Completed Interviews"
              value={overview?.completed_interviews ?? 0}
              icon={Activity}
              color="text-emerald-600"
            />

            <StatCard
              title="Average Candidate Score"
              value={`${overview?.average_candidate_score ?? 0}/10`}
              icon={Award}
              color="text-amber-600"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">

            {/* COMMON STRENGTHS */}
            <div className="bg-white border border-gray-200 rounded-xl p-5">
              <h3 className="font-bold text-gray-800 flex items-center mb-4">
                <TrendingUp className="w-5 h-5 text-emerald-600 mr-2" />
                Common Candidate Strengths
              </h3>

              {overview?.most_common_strengths?.length ? (
                <div className="space-y-3">
                  {overview.most_common_strengths.map((item, index) => (
                    <div
                      key={index}
                      className="flex justify-between items-center bg-emerald-50 p-3 rounded-lg"
                    >
                      <span className="text-sm text-emerald-900">
                        {item.name}
                      </span>

                      <span className="text-xs font-bold text-emerald-700">
                        {item.count} mentions
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-400">
                  No evaluation strengths available yet.
                </p>
              )}
            </div>

            {/* COMMON IMPROVEMENTS */}
            <div className="bg-white border border-gray-200 rounded-xl p-5">
              <h3 className="font-bold text-gray-800 flex items-center mb-4">
                <TrendingDown className="w-5 h-5 text-amber-600 mr-2" />
                Common Improvement Areas
              </h3>

              {overview?.most_common_improvements?.length ? (
                <div className="space-y-3">
                  {overview.most_common_improvements.map((item, index) => (
                    <div
                      key={index}
                      className="flex justify-between items-center bg-amber-50 p-3 rounded-lg"
                    >
                      <span className="text-sm text-amber-900">
                        {item.name}
                      </span>

                      <span className="text-xs font-bold text-amber-700">
                        {item.count} mentions
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-400">
                  No improvement data available yet.
                </p>
              )}
            </div>

          </div>
        </div>
      )}

      {/* CANDIDATE ANALYTICS */}
      {activeTab === 'candidates' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

          {/* CANDIDATE LIST */}
          <div className="bg-white border border-gray-200 rounded-xl p-4">
            <h3 className="font-bold text-gray-800 mb-4">
              All Candidates
            </h3>

            <div className="space-y-2">
              {(overview?.candidates || []).map(candidate => (
                <button
                  key={candidate.username}
                  onClick={() => setSelectedCandidate(candidate)}
                  className={`w-full text-left p-3 rounded-lg border ${
                    selectedCandidate?.username === candidate.username
                      ? 'bg-purple-50 border-purple-300'
                      : 'bg-white border-gray-100 hover:bg-gray-50'
                  }`}
                >
                  <div className="font-semibold text-sm text-gray-800">
                    {candidate.username}
                  </div>

                  <div className="text-xs text-gray-500 mt-1">
                    {candidate.completed_interviews} completed interviews
                  </div>

                  <div className="text-sm text-purple-700 font-bold mt-1">
                    Average: {candidate.average_score}/10
                  </div>
                </button>
              ))}

              {!overview?.candidates?.length && (
                <p className="text-sm text-gray-400">
                  No candidates found.
                </p>
              )}
            </div>
          </div>

          {/* SELECTED CANDIDATE DETAILS */}
          <div className="lg:col-span-2 bg-white border border-gray-200 rounded-xl p-6">
            {selectedCandidate ? (
              <div className="space-y-5">

                <div className="border-b pb-4">
                  <h3 className="text-xl font-bold text-gray-800">
                    {selectedCandidate.username}
                  </h3>

                  <p className="text-xs text-gray-500 mt-1">
                    Candidate Overall Performance
                  </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">

                  <div className="bg-blue-50 rounded-lg p-3">
                    <p className="text-xs text-blue-600">
                      Total Attempts
                    </p>

                    <p className="text-xl font-bold text-blue-800">
                      {selectedCandidate.total_interviews}
                    </p>
                  </div>

                  <div className="bg-purple-50 rounded-lg p-3">
                    <p className="text-xs text-purple-600">
                      Completed
                    </p>

                    <p className="text-xl font-bold text-purple-800">
                      {selectedCandidate.completed_interviews}
                    </p>
                  </div>

                  <div className="bg-emerald-50 rounded-lg p-3">
                    <p className="text-xs text-emerald-600">
                      Average Score
                    </p>

                    <p className="text-xl font-bold text-emerald-800">
                      {selectedCandidate.average_score}/10
                    </p>
                  </div>

                  <div className="bg-amber-50 rounded-lg p-3">
                    <p className="text-xs text-amber-600">
                      Latest Score
                    </p>

                    <p className="text-xl font-bold text-amber-800">
                      {selectedCandidate.latest_score}/10
                    </p>
                  </div>

                </div>

                {/* PERFORMANCE PROGRESS */}
                <div className="bg-gray-50 border border-gray-200 p-4 rounded-lg">
                  <h4 className="font-bold text-sm text-gray-800 mb-2">
                    Performance Progress
                  </h4>

                  <div className="flex justify-between text-sm">
                    <span>
                      First score: {selectedCandidate.first_score}/10
                    </span>

                    <span>
                      Latest score: {selectedCandidate.latest_score}/10
                    </span>
                  </div>

                  <div className="mt-3 flex items-center space-x-2">
                    {selectedCandidate.progress === 'Improving' ? (
                      <TrendingUp className="w-5 h-5 text-emerald-600" />
                    ) : selectedCandidate.progress === 'Needs Improvement' ? (
                      <TrendingDown className="w-5 h-5 text-red-600" />
                    ) : (
                      <Minus className="w-5 h-5 text-gray-500" />
                    )}

                    <span className="font-semibold text-sm text-gray-700">
                      {selectedCandidate.progress}
                    </span>
                  </div>
                </div>

                {/* INTERVIEW ROLES */}
                <div>
                  <h4 className="font-bold text-sm text-gray-800 mb-2">
                    Interview Roles
                  </h4>

                  <div className="flex flex-wrap gap-2">
                    {Object.keys(selectedCandidate.roles || {}).map(role => (
                      <span
                        key={role}
                        className="text-xs bg-blue-50 text-blue-700 px-3 py-2 rounded-lg"
                      >
                        {role}
                      </span>
                    ))}
                  </div>
                </div>

                {/* STRENGTHS AND IMPROVEMENTS */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

                  <div className="border border-emerald-100 bg-emerald-50 p-4 rounded-lg">
                    <h4 className="font-bold text-sm text-emerald-900 mb-2">
                      Candidate Strengths
                    </h4>

                    {selectedCandidate.key_strengths?.length ? (
                      <ul className="list-disc list-inside text-xs text-emerald-800 space-y-1">
                        {selectedCandidate.key_strengths.map((item, index) => (
                          <li key={index}>{item}</li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-xs text-gray-500">
                        No strengths recorded.
                      </p>
                    )}
                  </div>

                  <div className="border border-amber-100 bg-amber-50 p-4 rounded-lg">
                    <h4 className="font-bold text-sm text-amber-900 mb-2">
                      Areas to Improve
                    </h4>

                    {selectedCandidate.areas_for_improvement?.length ? (
                      <ul className="list-disc list-inside text-xs text-amber-800 space-y-1">
                        {selectedCandidate.areas_for_improvement.map((item, index) => (
                          <li key={index}>{item}</li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-xs text-gray-500">
                        No improvement areas recorded.
                      </p>
                    )}
                  </div>

                </div>

                <p className="text-xs text-gray-400">
                  Last interview: {selectedCandidate.last_interview}
                </p>

              </div>
            ) : (
              <p className="text-sm text-gray-400">
                Select a candidate to view their overall performance.
              </p>
            )}
          </div>
        </div>
      )}

      {/* AI AGENT FEEDBACK */}
      {activeTab === 'feedback' && (
        <div className="space-y-5">

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <StatCard
              title="Feedback Responses"
              value={agentFeedback?.total_responses ?? 0}
              icon={MessageSquare}
              color="text-blue-600"
            />

            <StatCard
              title="Average Agent Rating"
              value={`${agentFeedback?.average_rating ?? 0}/5`}
              icon={Star}
              color="text-amber-500"
            />

            <StatCard
              title="Would Recommend"
              value={`${agentFeedback?.recommendation_rate ?? 0}%`}
              icon={ThumbsUp}
              color="text-emerald-600"
            />
          </div>

          {/* RELEVANCE ANALYSIS */}
          <div className="bg-white border border-gray-200 rounded-xl p-5">
            <h3 className="font-bold text-gray-800 mb-4">
              Question Relevance Analysis
            </h3>

            {Object.entries(
              agentFeedback?.relevance_breakdown || {}
            ).map(([name, count]) => (
              <div
                key={name}
                className="flex justify-between items-center border-b py-3 text-sm"
              >
                <span className="text-gray-700">
                  {name}
                </span>

                <span className="font-bold text-purple-700">
                  {count} responses
                </span>
              </div>
            ))}

            {!agentFeedback?.total_responses && (
              <p className="text-sm text-gray-400">
                No agent feedback has been submitted yet.
              </p>
            )}
          </div>

          {/* CANDIDATE COMMENTS */}
          <div className="bg-white border border-gray-200 rounded-xl p-5">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center">
              <Bot className="w-5 h-5 text-purple-600 mr-2" />
              Candidate Feedback and Comments
            </h3>

            <div className="space-y-4">
              {(agentFeedback?.feedback || []).map(item => (
                <div
                  key={item.id}
                  className="border border-gray-200 rounded-lg p-4 space-y-3"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-sm text-gray-800">
                        {item.username}
                      </h4>

                      <p className="text-xs text-gray-500 mt-1">
                        {item.role} • {item.date}
                      </p>
                    </div>

                    <div className="text-amber-500 font-bold text-sm">
                      {'★'.repeat(item.rating || 0)}
                      {'☆'.repeat(5 - (item.rating || 0))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="bg-purple-50 p-3 rounded-lg">
                      <span className="font-semibold text-purple-800">
                        Question relevance
                      </span>

                      <p className="text-purple-700 mt-1">
                        {item.question_relevance}
                      </p>
                    </div>

                    <div className="bg-blue-50 p-3 rounded-lg">
                      <span className="font-semibold text-blue-800">
                        AI accuracy
                      </span>

                      <p className="text-blue-700 mt-1">
                        {item.agent_accuracy || 'Not provided'}
                      </p>
                    </div>
                  </div>

                  {item.feedback_text && (
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-xs font-semibold text-gray-600 mb-1">
                        Candidate comments
                      </p>

                      <p className="text-sm text-gray-700 whitespace-pre-wrap">
                        {item.feedback_text}
                      </p>
                    </div>
                  )}

                  <div className="text-xs text-gray-500">
                    Would recommend:{' '}

                    <span className={
                      item.would_recommend === null ||
                      item.would_recommend === undefined
                        ? 'text-gray-500 font-bold'
                        : item.would_recommend
                          ? 'text-emerald-600 font-bold'
                          : 'text-red-600 font-bold'
                    }>
                      {
                        item.would_recommend === null ||
                        item.would_recommend === undefined
                          ? 'Not provided'
                          : item.would_recommend
                            ? 'Yes'
                            : 'No'
                      }
                    </span>
                  </div>
                </div>
              ))}

              {!agentFeedback?.total_responses && (
                <p className="text-sm text-gray-400">
                  Waiting for candidate feedback submissions.
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* INDIVIDUAL INTERVIEW RECORDS */}
      {activeTab === 'interviews' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

          {/* INTERVIEW LIST */}
          <div className="bg-white border border-gray-200 rounded-xl p-4 max-h-[75vh] overflow-y-auto">
            <h3 className="font-bold text-gray-700 mb-3">
              All Interview Records
            </h3>

            {interviews.map(item => (
              <div
                key={item.id}
                onClick={() => setSelectedSession(item)}
                className={`py-3 px-2 rounded-lg cursor-pointer flex justify-between items-center ${
                  selectedSession?.id === item.id
                    ? 'bg-purple-50 border-l-4 border-purple-600'
                    : 'hover:bg-gray-50'
                }`}
              >
                <div>
                  <div className="font-semibold text-gray-800 text-sm">
                    {item.user_name}
                  </div>

                  <div className="text-xs text-gray-500 mt-1">
                    {item.role} • {item.date}
                  </div>

                  <div className="text-xs font-bold text-purple-700 mt-1">
                    Score: {item.overall_score}/10
                  </div>
                </div>

                <button
                  onClick={event => {
                    event.stopPropagation();
                    handleDelete(item.id);
                  }}
                  className="p-2 text-gray-400 hover:text-red-600"
                  title="Delete interview"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}

            {!interviews.length && (
              <p className="text-sm text-gray-400">
                No interviews found.
              </p>
            )}
          </div>

          {/* SELECTED INTERVIEW DETAILS */}
          {selectedSession && (
            <div className="lg:col-span-2 bg-white border border-gray-200 rounded-xl p-5 space-y-5 max-h-[75vh] overflow-y-auto">

              <div className="flex justify-between items-center border-b pb-4">
                <div>
                  <h3 className="font-bold text-lg text-gray-800">
                    {selectedSession.user_name}
                  </h3>

                  <p className="text-xs text-gray-500 mt-1">
                    {selectedSession.role} • {selectedSession.experience}
                  </p>
                </div>

                <div className="text-right">
                  <p className="text-xs text-gray-400">
                    Interview Score
                  </p>

                  <p className="text-xl font-extrabold text-purple-700">
                    {selectedSession.overall_score}/10
                  </p>
                </div>
              </div>

              {/* EVALUATION */}
              <div>
                <h4 className="font-bold text-sm text-gray-800 mb-2">
                  AI Evaluation Summary
                </h4>

                <p className="bg-gray-50 p-3 rounded-lg text-sm text-gray-700">
                  {selectedSession.feedback || 'Evaluation not available.'}
                </p>
              </div>

              {/* STRENGTHS AND IMPROVEMENTS */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">

                <div className="bg-amber-50 p-3 rounded-lg">
                  <h4 className="font-bold text-xs text-amber-900 mb-2">
                    Areas for Improvement
                  </h4>

                  <ul className="list-disc list-inside text-xs text-amber-800 space-y-1">
                    {selectedSession.areas_for_improvement?.map((item, index) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                </div>

                <div className="bg-emerald-50 p-3 rounded-lg">
                  <h4 className="font-bold text-xs text-emerald-900 mb-2">
                    Key Strengths
                  </h4>

                  <ul className="list-disc list-inside text-xs text-emerald-800 space-y-1">
                    {selectedSession.key_strengths?.map((item, index) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* TRANSCRIPT */}
              <div>
                <h4 className="font-bold text-sm text-gray-800 mb-2">
                  Interview Transcript
                </h4>

                <div className="space-y-3 bg-gray-50 p-3 rounded-xl">
                  {selectedSession.transcript?.length ? (
                    selectedSession.transcript.map((message, index) => (
                      <div
                        key={index}
                        className={`p-3 rounded-lg text-xs ${
                          message.sender === 'user'
                            ? 'bg-purple-100 text-purple-900 ml-5'
                            : 'bg-white text-gray-800 mr-5 border'
                        }`}
                      >
                        <p className="font-bold uppercase text-[10px] mb-1">
                          {message.sender} • {message.time}
                        </p>

                        {message.message}
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-gray-400">
                      No transcript available.
                    </p>
                  )}
                </div>
              </div>

              {/* CANDIDATE FEEDBACK */}
              <div className="flex justify-between items-center gap-3">
                <div>
                  <h4 className="font-bold text-sm text-gray-800">
                    Candidate's Agent Feedback
                  </h4>

                  {selectedSession.agent_feedback ? (
                    <p className="text-xs text-purple-700 mt-1">
                      {'★'.repeat(selectedSession.agent_feedback.rating || 0)}
                      {'☆'.repeat(5 - (selectedSession.agent_feedback.rating || 0))}
                      {' • '}
                      {selectedSession.agent_feedback.question_relevance}
                    </p>
                  ) : (
                    <p className="text-xs text-gray-400 mt-1">
                      No feedback submitted.
                    </p>
                  )}
                </div>

                <button
                  onClick={() => handleDelete(selectedSession.id)}
                  className="bg-red-50 text-red-600 border border-red-200 px-3 py-2 rounded-lg text-xs font-medium"
                >
                  <Trash2 className="w-4 h-4 inline mr-1" />
                  Delete Record
                </button>
              </div>

            </div>
          )}
        </div>
      )}

    </div>
  );
}