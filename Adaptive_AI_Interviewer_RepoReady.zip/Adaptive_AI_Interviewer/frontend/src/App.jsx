
import React, { useState } from 'react';

import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Setup from './pages/Setup';
import Interview from './pages/Interview';
import AdminPortal from './pages/AdminPortal';

import {
  LogOut,
  PlayCircle,
  Shield,
  LayoutDashboard
} from 'lucide-react';

import {
  startInterview,
  sendAnswer,
  completeInterview
} from './services/api';


export default function App() {

  const [currentUser, setCurrentUser] = useState(null);
  const [currentView, setCurrentView] = useState('setup');

  const [interviewSession, setInterviewSession] = useState(null);
  const [currentResult, setCurrentResult] = useState(null);

  const [startingInterview, setStartingInterview] = useState(false);
  const [appError, setAppError] = useState('');


  // LOGIN
  const handleLoginSuccess = (userData) => {

    setCurrentUser(userData);
    setCurrentResult(null);
    setInterviewSession(null);
    setAppError('');

    setCurrentView(
      userData.role?.toLowerCase() === 'admin'
        ? 'admin'
        : 'setup'
    );
  };


  // LOGOUT
  const handleLogout = () => {

    setCurrentUser(null);
    setCurrentResult(null);
    setInterviewSession(null);

    setStartingInterview(false);
    setAppError('');

    setCurrentView('setup');
  };


  // START INTERVIEW
  const handleStartInterview = async (config) => {

    if (startingInterview || interviewSession) return;

    setStartingInterview(true);
    setAppError('');

    try {

      console.log('Starting interview:', config);

      // START BACKEND SESSION
      const data = await startInterview({
        ...config,
        username: currentUser.username,
        user_name: currentUser.username
      });

      console.log('Backend response:', data);

      if (!data?.session_id || !data?.question) {

        throw new Error(
          'Backend did not return a valid session ID or initial question.'
        );

      }


      // CREATE INTERVIEW SESSION
      const session = {

        id: data.session_id,
        session_id: data.session_id,

        username: currentUser.username,
        user_name: currentUser.username,

        role: config.role,
        experience: config.experience,
        interview_type: config.interview_type,

        time_limit_minutes: Number(
          data.time_limit_minutes ||
          config.time_limit_minutes ||
          10
        ),

        initialQuestion: data.question,


        // SEND CANDIDATE ANSWER
        onSendAnswer: async (answer) => {

          const response = await sendAnswer(
            data.session_id,
            answer
          );

          if (!response?.question) {

            throw new Error(
              'AI interviewer did not return the next question.'
            );

          }

          return response.question;

        },


        // COMPLETE INTERVIEW
        onFinish: async () => {

          console.log(
            'Completing interview:',
            data.session_id
          );

          // SAVE AND EVALUATE INTERVIEW
          const result = await completeInterview(
            data.session_id
          );

          if (!result) {

            throw new Error(
              'Backend returned an empty interview evaluation.'
            );

          }


          // STORE COMPLETE RESULT
          const finalResult = {

            ...result,

            session_id: data.session_id,

            username: currentUser.username,
            user_name: currentUser.username,

            role: config.role,
            experience: config.experience,
            interview_type: config.interview_type

          };

          console.log(
            'Final interview evaluation:',
            finalResult
          );


          // UPDATE APPLICATION STATE
          setCurrentResult(finalResult);

          setInterviewSession(null);

          setAppError('');

          setCurrentView('dashboard');

          return finalResult;

        }

      };


      // SAVE SESSION
      setInterviewSession(session);

      // OPEN INTERVIEW
      setCurrentView('interview');

    } catch (error) {

      console.error(
        'Interview start failed:',
        error
      );

      const message =
        error.response?.data?.error ||
        error.response?.data?.message ||
        error.message;

      setAppError(
        `Could not start interview: ${message}. Please check Flask backend and Ollama.`
      );

    } finally {

      setStartingInterview(false);

    }

  };


  // LOGIN SCREEN
  if (!currentUser) {

    return (
      <Login
        onLoginSuccess={handleLoginSuccess}
      />
    );

  }


  const isAdmin =
    currentUser.role?.toLowerCase() === 'admin';


  return (

    <div className="min-h-screen bg-gray-50 flex flex-col">


      {/* HEADER */}

      <header className="bg-white border-b border-gray-200 px-6 py-3.5 flex justify-between items-center shadow-sm">

        <div className="flex items-center space-x-3">

          <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">

            🤖

          </div>

          <div>

            <h1 className="font-bold text-gray-900 text-base">

              Adaptive AI Interviewer (Ollama Local)

            </h1>

            <p className="text-xs text-gray-500">

              BITS Pilani Design Project MVP

            </p>

          </div>

        </div>


        {/* NAVIGATION */}

        <div className="flex items-center space-x-4">


          {!isAdmin ? (

            <>

              <button

                onClick={() => {

                  if (interviewSession) return;

                  setAppError('');
                  setCurrentResult(null);
                  setCurrentView('setup');

                }}

                disabled={!!interviewSession}

                className="inline-flex items-center space-x-1.5 bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-1.5 rounded-lg text-xs font-semibold disabled:opacity-50"

              >

                <PlayCircle className="w-4 h-4" />

                <span>New Session</span>

              </button>


              <button

                onClick={() => {

                  if (!interviewSession) {
                    setCurrentView('dashboard');
                  }

                }}

                disabled={!!interviewSession}

                className="inline-flex items-center space-x-1.5 text-xs font-semibold text-gray-700 hover:text-blue-600 px-2 py-1 disabled:opacity-50"

              >

                <LayoutDashboard className="w-4 h-4" />

                <span>Dashboard &amp; History</span>

              </button>

            </>

          ) : (

            <button

              onClick={() => setCurrentView('admin')}

              className="inline-flex items-center space-x-1.5 bg-purple-600 text-white px-3.5 py-1.5 rounded-lg text-xs font-semibold"

            >

              <Shield className="w-4 h-4" />

              <span>Admin Supervision Portal</span>

            </button>

          )}


          <div className="h-5 w-px bg-gray-200" />


          {/* USER DETAILS */}

          <div className="flex items-center space-x-2 bg-gray-100 px-3 py-1.5 rounded-lg text-xs font-semibold">

            <span>{currentUser.username}</span>

            <span className="px-2 py-0.5 rounded text-white bg-blue-600">

              {currentUser.role?.toUpperCase()}

            </span>

          </div>


          {/* LOGOUT */}

          <button

            onClick={handleLogout}

            className="p-1.5 text-gray-400 hover:text-red-600 rounded-lg"

            title="Logout"

          >

            <LogOut className="w-4 h-4" />

          </button>

        </div>

      </header>


      {/* MAIN CONTENT */}

      <main className="flex-1 p-6">


        {/* APPLICATION ERROR */}

        {appError && (

          <div

            role="alert"

            className="max-w-2xl mx-auto mt-5 mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"

          >

            {appError}

            <button

              onClick={() => setAppError('')}

              className="ml-3 font-bold"

            >

              ×

            </button>

          </div>

        )}


        {/* ADMIN PORTAL */}

        {currentView === 'admin' && isAdmin ? (

          <AdminPortal />

        ) : null}


        {/* INTERVIEW SETUP */}

        {currentView === 'setup' && !isAdmin ? (

          <Setup

            currentUser={currentUser}

            onStart={handleStartInterview}

            loading={startingInterview}

          />

        ) : null}


        {/* ACTIVE INTERVIEW */}

        {currentView === 'interview' && interviewSession ? (

          <Interview

            key={interviewSession.session_id}

            session={interviewSession}

          />

        ) : null}


        {/* DASHBOARD AND HISTORY */}

        {currentView === 'dashboard' && !isAdmin ? (

          <Dashboard

            currentResult={currentResult}

            currentUser={currentUser}

          />

        ) : null}


      </main>

    </div>

  );

}
